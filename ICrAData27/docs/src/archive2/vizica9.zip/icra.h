/// ICrA header

struct vizres makeICrA(double** matW, int rows, int cols, int method, int type, int matcnt);
void freevres(struct vizres vres);
void freevdata(struct vizdata vdata);

