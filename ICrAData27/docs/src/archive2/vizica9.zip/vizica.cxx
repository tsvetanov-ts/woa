/**
 * 
 * VizicA
 * 
 * Author: Nikolay Ikonomov
 * Version: alpha9
 * Date: December 18, 2019
 * Compiled by: GCC 7.3.0 (Linux), TDM-GCC 5.1.0 (Win32/Win64)
 * 
 */

#include "vizica.h"
#include "icra.h"
#include "strfun.h"
#include "zerofun.h"

int main() {
	
	printf("VizicA\n");
	
	/// filename, separator, headers, transpose
	struct vizdata vdata = readFile("ex3.txt", ';', 0, 0);
	
	//printf("\nmatW\n");
	//showDoubleMatrix(vdata.matW, vdata.rW, vdata.cW);
	
	/// matrix, rows, cols, method, type, matrix count
	struct vizres vres = makeICrA(vdata.matW, vdata.rW, vdata.cW, 1, 5, 100);
	
	printf("\nmatR\n");
	showDoubleMatrix(vres.matR, vres.size, vres.size);
	
	freevres(vres);
	freevdata(vdata);
	
	return 0;
}

