/// VizicA header

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#ifndef min
#define min(a,b) ((a) < (b) ? (a) : (b))
#endif
#ifndef max
#define max(a,b) ((a) > (b) ? (a) : (b))
#endif

/// Structs
struct theres {
	double** matR;
	int      rows;
};

