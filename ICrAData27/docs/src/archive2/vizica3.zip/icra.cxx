/// ICrA - InterCriteria Analysis

#include "vizica.h"
#include "zerofun.h"

/// Make criteria matrix
double** makeCrit(double** matA, int rows, int cols) {
	
	double** matC = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matC[i] = (double*) malloc(sizeof(double) * ((cols*(cols-1))/2));
	zeroDoubleMatrix(matC, rows, (cols*(cols-1))/2);
	
	int cc = 0;
	for (int i = 0; i < rows; i++) {
		for (int k = 0; k < cols-1; k++) {
			for (int j = k; j < cols-1; j++) {
				matC[i][cc] = (matA[i][k]-matA[i][j+1] > 0 ? 1 : (matA[i][k]-matA[i][j+1] < 0 ? -1 : 0));
				cc++;
			}
		}
		cc = 0;
	}
	
	return matC;
}

/// Make criteria matrix for ordered pair
double** makeCritPair(double** matA, double** matB, int rows, int cols) {
	
	double** matC = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matC[i] = (double*) malloc(sizeof(double) * ((cols*(cols-1))/2));
	zeroDoubleMatrix(matC, rows, (cols*(cols-1))/2);
	
	int cc = 0;
	for (int i = 0; i < rows; i++) {
		for (int k = 0; k < cols-1; k++) {
			for (int j = k; j < cols-1; j++) {
				if (matA[i][k] >= matA[i][j+1] && matB[i][k] < matB[i][j+1])
					matC[i][cc] = 1;
				else if (matA[i][k] > matA[i][j+1] && matB[i][k] <= matB[i][j+1])
					matC[i][cc] = 1;
				else if (matA[i][k] <= matA[i][j+1] && matB[i][k] > matB[i][j+1])
					matC[i][cc] = -1;
				else if (matA[i][k] < matA[i][j+1] && matB[i][k] >= matB[i][j+1])
					matC[i][cc] = -1;
				else if (matA[i][k] == matA[i][j+1] && matB[i][k] == matB[i][j+1])
					matC[i][cc] = 0;
				else
					matC[i][cc] = 9;
				cc++;
			}
		}
		cc = 0;
	}
	
	return matC;
}

/// Counter A - equal elements:  0==0  -1==-1  1==1  (flag==1)   0=/=0  -1==-1  1==1  (flag==0)
double counterA(double* arrA, double* arrB, int size, int flag) {
	
	int cc = 0;
	for (int i = 0; i < size; i++) {
		if (((arrA[i] ==  1) && (arrB[i] ==  1)) ||
			((arrA[i] == -1) && (arrB[i] == -1)) ||
			((arrA[i] ==  0) && (arrB[i] ==  0) && flag))
			cc++;
	}
	
	return (double)cc/size;
}

/// Counter B - different elements:  0==0  -1=/=1  1=/=-1  (flag==0)   0=/=0  -1=/=1  1=/=-1  (flag==1)
double counterB(double* arrA, double* arrB, int size, int flag) {
	
	int cc = 0;
	for (int i = 0; i < size; i++) {
		if (((arrA[i] == -1) && (arrB[i] ==  1)) ||
			((arrA[i] ==  1) && (arrB[i] == -1)) ||
			((arrA[i] ==  0) && (arrB[i] ==  0) && flag))
			cc++;
	}
	
	return (double)cc/size;
}

/// Make result - mubiased1 flags 1 0, unbiased2 flags 0 0, nubiased3 flags 0 1
double** makeResult(double** matC, int rows, int cols, int method) {
	
	double** matR = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matR[i] = (double*) malloc(sizeof(double) * rows);
	zeroDoubleMatrix(matR, rows, rows);
	
	for (int i = 0; i < rows; i++) {
		/// upper triangular - matrix MU-A
		for (int j = i+1; j < rows; j++)
			matR[i][j] = counterA(matC[i], matC[j], cols, (method==1 ? 1 : 0));
		/// lower triangular - matrix NU-B
		for (int j = 0; j < i; j++)
			matR[i][j] = counterB(matC[i], matC[j], cols, (method==3 ? 1 : 0));
		/// ignore diagonal elements
	}
	
	return matR;
}

/// Balanced4 - mean value for mubiasedR1 and nubiasedR3 - (R1{i,j} + R3{i,j})/2
double** methodBalanced(double** matR1, double** matR3, int rows) {
	
	double** matR = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matR[i] = (double*) malloc(sizeof(double) * rows);
	zeroDoubleMatrix(matR, rows, rows);
	
	for (int i = 0; i < rows; i++)
		for (int j = 0; j < rows; j++)
			if (i != j)
				matR[i][j] = (matR1[i][j] + matR3[i][j])/2;
	
	return matR;
}

/// Weighted5 - each element of unbiasedR2 divided by the sum of MU+NU - R2{i,j}/(R2{i,j} + R2{j,i})
double** methodWeighted(double** matR2, int rows) {
	
	double** matR = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matR[i] = (double*) malloc(sizeof(double) * rows);
	zeroDoubleMatrix(matR, rows, rows);
	
	for (int i = 0; i < rows; i++)
		for (int j = 0; j < rows; j++)
			if (i != j)
				matR[i][j] = matR2[i][j]/(matR2[i][j] + matR2[j][i]);
	
	return matR;
}

/// Free matrix data
void freeMatrix(double** matA, int rows) {
	if (matA != NULL) {
		for (int i = 0; i < rows; i++)
			free(matA[i]);
		free(matA);
	}
}

/// Make calculations
struct theres makeCalc(double** matW, double** matW2, int rows, int cols, int method, int pair) {
	
	/// Matrix dimensions
	/// matW rows cols
	/// matC rows (cols*(cols-1))/2
	/// matR rows rows
	
	/// Criteria matrix - sign of difference between elements per row
	double** matC = (pair ? makeCritPair(matW, matW2, rows, cols) : makeCrit(matW, rows, cols));
	
	printf("\nmatC\n");
	showDoubleMatrix(matC, rows, (cols*(cols-1))/2);
	
	/// Result matrix - MU-A uppper triangular, NU-A lower triangular, ignore diagonal elements
	double** matR = NULL;
	
	/// Method - muBiased1, Unbiased2, nuBiased3, Balanced4, Weighted5
	if (method == 1 || method == 2 || method == 3)
		matR = makeResult(matC, rows, (cols*(cols-1))/2, method);
		
	else if (method == 4) {
		double** matR1 = makeResult(matC, rows, (cols*(cols-1))/2, 1);
		double** matR3 = makeResult(matC, rows, (cols*(cols-1))/2, 3);
		matR = methodBalanced(matR1, matR3, rows); /// mean value of 1 and 3
		freeMatrix(matR3, rows);
		freeMatrix(matR1, rows);
		
	} else if (method == 5) {
		double** matR2 = makeResult(matC, rows, (cols*(cols-1))/2, 2);
		matR = methodWeighted(matR2, rows); /// each element of 2 divided by the sum of (i,j)+(j,i)
		freeMatrix(matR2, rows);
	}
	
	freeMatrix(matC, rows);
	freeMatrix(matW, rows);
	
	/// Result
	struct theres res;
	res.matR = matR;
	res.rows = rows;
	
	return res;
}

