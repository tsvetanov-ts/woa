/// ICrA header

struct theres makeCalc(double** matW, double** matW2, int rows, int cols, int method, int pair);

