/// ICrA header

struct vizres makeICrA(double** matW, int rows, int cols, int icavar, int icamth, int matcnt);

