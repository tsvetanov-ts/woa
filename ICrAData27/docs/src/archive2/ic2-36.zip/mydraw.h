/// MyDraw header

#include <FL/Fl_Box.H>

class MyDraw : public Fl_Box {
	private:
		double** wdata;
		int      wsize;
		double    lima;
		double    limb;
	protected:
		void draw();
		Fl_Color myColor(int r, int c);
	public:
		MyDraw(int x, int y, int w, int h, const char* lbl);
		void myPlotData(double** wd, int ws);
		void myLimitA(double a);
		void myLimitB(double b);
};

