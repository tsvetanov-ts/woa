/// MyDraw

#include <FL/Fl.H>
#include <FL/fl_draw.H>

#include "mydraw.h"

/// MyDraw - constructor
MyDraw::MyDraw(int x, int y, int w, int h, const char* lbl) : Fl_Box(x, y, w, h, lbl) {
	myPlotData(NULL, -1);
	myLimitA(0.75);
	myLimitB(0.25);
}

/// MyDraw - plot data
void MyDraw::myPlotData(double** wd, int ws) {
	wdata = wd;
	wsize = ws;
}

void MyDraw::myLimitA(double a) { lima = a; }
void MyDraw::myLimitB(double b) { limb = b; }

/// MyDraw - color based on limits
Fl_Color MyDraw::myColor(int r, int c) {
	
	if (wsize > 0 && r != c) {
		if (wdata[r][c] > lima && wdata[c][r] < limb)
			return (r < c ? FL_DARK_GREEN : FL_RED);
		else if (wdata[r][c] < limb && wdata[c][r] > lima)
			return (r < c ? FL_RED : FL_DARK_GREEN);
		else
			return FL_MAGENTA;
	}
	
	return Fl::get_color(FL_FOREGROUND_COLOR);
}

/// Draw
void MyDraw::draw() {
	
	int x = this->x();
	int y = this->y();
	int w = this->w();
	int h = this->h();
	
	int mm = (w < h ? w : h);
	
	fl_color(FL_CYAN);
	//fl_color(Fl::get_color(FL_FOREGROUND_COLOR));
	
	fl_line_style(0);
	//fl_line(x+0,y+0,x+w+0,y+h+0);
	
	fl_circle(x+20,   y+20,   20);
	fl_circle(x+w-20, y+20,   20);
	fl_circle(x+20,   y+h-20, 20);
	fl_circle(x+w-20, y+h-20, 20);
	
	fl_circle(x+60,y+60,20);
	
	int dd = 20;
	fl_line(x+dd, y+dd,    x+dd,    y+mm-dd); /// left
	fl_line(x+dd, y+mm-dd, x+mm-dd, y+mm-dd); /// bottom
	fl_line(x+dd, y+dd,    x+mm-dd, y+mm-dd); /// main diagonal
	
	int nn = mm-2*dd;
	int rr = 5;
	
	if (wsize > 0) {
		for (int i = 0; i < wsize; i++) {
			for (int j = 0; j < wsize; j++) {
				if (i < j) {
					fl_color(myColor(i,j));
					fl_circle(x+dd+wdata[i][j]*nn, y+nn+dd-wdata[j][i]*nn, rr);
					//fl_pie(x+dd+wdata[i][j]*nn-rr, y+nn+dd-wdata[j][i]*nn-rr, 2*rr, 2*rr, 0, 360);
				}
			}
		}
	}
}

