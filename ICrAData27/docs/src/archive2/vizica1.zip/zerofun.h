/// Zero/show functions of array/matrix header

void zeroIntArray(int* arr, int size);
void showIntArray(int* arr, int size);
void zeroIntMatrix(int** mat, int row, int col);
void showIntMatrix(int** mat, int row, int col);

void zeroDoubleArray(double* arr, int size);
void showDoubleArray(double* arr, int size);
void zeroDoubleMatrix(double** mat, int row, int col);
void showDoubleMatrix(double** mat, int row, int col);

