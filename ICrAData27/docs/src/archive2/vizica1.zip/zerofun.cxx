/// Zero/show functions of array/matrix

#include <stdio.h>
#include <stdlib.h>

/// Integer array
void zeroIntArray(int* arr, int size) {
	for (int i = 0; i < size; i++)
		arr[i] = (int)0;
}

void showIntArray(int* arr, int size) {
	for (int i = 0; i < size; i++)
		printf("%d ", arr[i]);
}

/// Integer matrix
void zeroIntMatrix(int** mat, int row, int col) {
	for (int i = 0; i < row; i++)
		for (int j = 0; j < col; j++)
			mat[i][j] = (int)0;
}

void showIntMatrix(int** mat, int row, int col) {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++)
			printf("%d ", mat[i][j]);
		printf("\n");
	}
}

/// Double array
void zeroDoubleArray(double* arr, int size) {
	for (int i = 0; i < size; i++)
		arr[i] = (double)0;
}

void showDoubleArray(double* arr, int size) {
	for (int i = 0; i < size; i++)
		printf("%.2f ", arr[i]);
}

/// Double matrix
void zeroDoubleMatrix(double** mat, int row, int col) {
	for (int i = 0; i < row; i++)
		for (int j = 0; j < col; j++)
			mat[i][j] = (double)0;
}

void showDoubleMatrix(double** mat, int row, int col) {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++)
			printf("%.2f ", mat[i][j]);
		printf("\n");
	}
}

