/// MyGL

/// FLTK uses WIN32 flag
#if defined(_WIN32) && !defined(WIN32)
#define WIN32
#endif

#include <FL/gl.h>
#include <FL/glu.h>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>

#include "mygl.h"

#include <math.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef convtorad
#define convtorad(x) ((x)*(M_PI/180.0))
#endif
#ifndef convtodeg
#define convtodeg(x) ((x)*(180.0/M_PI))
#endif

/// Structs
struct vec {
	double x;
	double y;
	double z;
};

/// MyWindow - constructor
MyWindow::MyWindow(int x, int y, int w, int h, const char* lbl) : Fl_Gl_Window(x, y, w, h, lbl) {
}

/// MyWindow - events
int MyWindow::handle(int event) {
	switch (event) {
	case FL_FOCUS:
		return 1;
	case FL_UNFOCUS:
		return 1;
	case FL_ENTER:
		return 1;
	case FL_MOVE:
		Fl::focus(this);
		mX = Fl::event_x();
		mY = Fl::event_y();
		redraw();
		return 1;
	case FL_LEAVE:
		return 1;
	case FL_PUSH:
		mX = Fl::event_x();
		mY = Fl::event_y();
		return 1;
	case FL_DRAG:
		mDX = Fl::event_x();
		mDY = Fl::event_y();
		/// Mouse is on the screen: X from left to right, Y from top to bottom
		if (Fl::event_button() == FL_LEFT_MOUSE) {
				 if (mDX-mX >  mpix && mDY-mY >  mpix) msb = 34; /// X+ Y+
			else if (mDX-mX < -mpix && mDY-mY < -mpix) msb = 33; /// X- Y-
			else if (mDX-mX >  mpix && mDY-mY < -mpix) msb = 32; /// X+ Y-
			else if (mDX-mX < -mpix && mDY-mY >  mpix) msb = 31; /// X- Y+
			mX = mDX;
			mY = mDY;
		}
		redraw();
		return 1;
	case FL_RELEASE:
		return 1;
	case FL_MOUSEWHEEL:
		msw = Fl::event_dy();
		redraw();
		return 1;
	case FL_KEYDOWN:
		/// Ctrl Fl::event_command() Alt Fl::event_alt() Shift Fl::event_shift()
		
		/// Keyboard - 0marker, 1movement
		if (Fl::event_key() == 'c')
			kbdstate = (kbdstate ? 0 : 1);
		
		/// Rotate the camera eye on shift+d,a,w,s,e,q with locked origin point
		else if (Fl::event_shift() && (Fl::event_key() == 'd' || Fl::event_key() == FL_Right)    ) { if (kbdstate) kbd = 21; }
		else if (Fl::event_shift() && (Fl::event_key() == 'a' || Fl::event_key() == FL_Left)     ) { if (kbdstate) kbd = 22; }
		else if (Fl::event_shift() && (Fl::event_key() == 'w' || Fl::event_key() == FL_Up)       ) { if (kbdstate) kbd = 23; }
		else if (Fl::event_shift() && (Fl::event_key() == 's' || Fl::event_key() == FL_Down)     ) { if (kbdstate) kbd = 24; }
		else if (Fl::event_shift() && (Fl::event_key() == 'e' || Fl::event_key() == FL_Page_Up)  ) { if (kbdstate) kbd = 25; }
		else if (Fl::event_shift() && (Fl::event_key() == 'q' || Fl::event_key() == FL_Page_Down)) { if (kbdstate) kbd = 26; }
		
		/// Move marker or translate the camera eye and origin point on d,a,w,s,e,q
		else if (Fl::event_key() == 'd' || Fl::event_key() == FL_Right      ) {
																				if (kbdstate) kbd = 11;
																				else { if (xmark < xel-1) xmark++; }
		} else if (Fl::event_key() == 'a' || Fl::event_key() == FL_Left     ) {
																				if (kbdstate) kbd = 12;
																				else { if (xmark > 0)     xmark--; }
		} else if (Fl::event_key() == 'w' || Fl::event_key() == FL_Up       ) {
																				if (kbdstate) kbd = 13;
																				else { if (ymark < yel-1) ymark++; }
		} else if (Fl::event_key() == 's' || Fl::event_key() == FL_Down     ) {
																				if (kbdstate) kbd = 14;
																				else { if (ymark > 0)     ymark--; }
		} else if (Fl::event_key() == 'e' || Fl::event_key() == FL_Page_Up  ) {
																				if (kbdstate) kbd = 15;
																				else { if (zmark < zel-1) zmark++; }
		} else if (Fl::event_key() == 'q' || Fl::event_key() == FL_Page_Down) {
																				if (kbdstate) kbd = 16;
																				else { if (zmark > 0)     zmark--; }
		}
		else if (Fl::event_key() == 'z' || Fl::event_key() == FL_End      ) kbd = 17;
		else if (Fl::event_key() == 'x' || Fl::event_key() == FL_Home     ) kbd = 18;
		
		
		/// Circle 1
		else if (Fl::event_key() == FL_F + 9)
			circle1 = (circle1 ? 0 : 1);
		/// Circle 2
		else if (Fl::event_key() == FL_F + 10)
			circle2 = (circle2 ? 0 : 1);
		/// Circle 3
		else if (Fl::event_key() == FL_F + 11)
			circle3 = (circle3 ? 0 : 1);
		
		/// Movement accuracy
		else if (Fl::event_key() == FL_F + 5) {
			if (acc > 0.2)  acc -= 0.1;
		} else if (Fl::event_key() == FL_F + 6) {
			if (acc < 4.99) acc += 0.1;
		}
		
		/// Rotation angle
		else if (Fl::event_key() == FL_F + 7) {
			if (theta > 15.0) theta -= 15.0;
		} else if (Fl::event_key() == FL_F + 8) {
			if (theta < 60.0) theta += 15.0;
		}
		
		/// Reset on Ctrl-R
		else if (Fl::event_command() && Fl::event_key() == 'r') {
			eyeX = 0.0; eyeY = -0.01; eyeZ = 3.0;
			locX = 0.0; locY = 0.0; locZ = 0.0;
		}
		
		/// Crosshair on Ctrl-H
		else if (Fl::event_command() && Fl::event_key() == 'h')
			crosshair = (crosshair ? 0 : 1);
		
		/// Wireframe on Ctrl-G
		else if (Fl::event_command() && Fl::event_key() == 'g')
			wireframe = (wireframe ? 0 : 1);
		
		/// Background grey/white
		else if (Fl::event_command() && Fl::event_key() == 'b')
			backclr = (backclr ? 0 : 1);
		
		redraw();
		return 1;
	case FL_KEYUP:
		return 1;
	default:
		return Fl_Gl_Window::handle(event);
	}
}

/// Draw crosshair at the look-at-origin
void drawCrosshair(float locX, float locY, float locZ, int ch) {
	if (ch) {
		float dd = 0.2;
		glColor3f(0,1,1);
		glBegin(GL_LINES);
		glVertex3f(locX+3*dd, locY, locZ);
		glVertex3f(locX  -dd, locY, locZ);
		glEnd();
		glColor3f(1,0,1);
		glBegin(GL_LINES);
		glVertex3f(locX, locY+3*dd, locZ);
		glVertex3f(locX, locY  -dd, locZ);
		glEnd();
		glColor3f(1,1,0);
		glBegin(GL_LINES);
		glVertex3f(locX, locY, locZ+3*dd);
		glVertex3f(locX, locY, locZ  -dd);
		glEnd();
	}
}

/// Cube
void drawCube(int ft) {
	GLenum gt = (ft ? GL_POLYGON : GL_LINE_LOOP);
	/// Front side
	glBegin(gt);
	glVertex3f( 1,  1,  1);
	glVertex3f(-1,  1,  1);
	glVertex3f(-1, -1,  1);
	glVertex3f( 1, -1,  1);
	glEnd();
	/// Back side
	glBegin(gt);
	glVertex3f( 1,  1, -1);
	glVertex3f( 1, -1, -1);
	glVertex3f(-1, -1, -1);
	glVertex3f(-1,  1, -1);
	glEnd();
	/// Left side
	glBegin(gt);
	glVertex3f(-1,  1,  1);
	glVertex3f(-1,  1, -1);
	glVertex3f(-1, -1, -1);
	glVertex3f(-1, -1,  1);
	glEnd();
	/// Right side
	glBegin(gt);
	glVertex3f( 1,  1,  1);
	glVertex3f( 1, -1,  1);
	glVertex3f( 1, -1, -1);
	glVertex3f( 1,  1, -1);
	glEnd();
	/// Up side
	glBegin(gt);
	glVertex3f( 1,  1,  1);
	glVertex3f( 1,  1, -1);
	glVertex3f(-1,  1, -1);
	glVertex3f(-1,  1,  1);
	glEnd();
	/// Down side
	glBegin(gt);
	glVertex3f( 1, -1,  1);
	glVertex3f(-1, -1,  1);
	glVertex3f(-1, -1, -1);
	glVertex3f( 1, -1, -1);
	glEnd();
}

/// Draw cluster
void drawCluster(int ft) {
	
	/// Draw cube
	glPushMatrix();
	glScalef(0.3, 0.3, 0.3);
	glColor3f(1, 0.7, 1);
	drawCube(ft);
	glPopMatrix();
	
	glPushMatrix();
	glScalef(0.5, 0.5, 0.5);
	glColor3f(1, 1, 0.5);
	drawCube(0);
	glPopMatrix();
	
	glPushMatrix(); /// duplicate
	glTranslatef(0.7, 0.7, 0.7);
	glScalef(0.3, 0.3, 0.3);
	glColor3f(1, 0.5, 0.5);
	drawCube(ft);
	glPopMatrix(); /// restore
	
	glPushMatrix(); /// duplicate
	glTranslatef(-0.7, -0.7, -0.7);
	glRotatef(45, 0,0,1);
	glScalef(0.3, 0.3, 0.3);
	glColor3f(0.2, 0.7, 0.5);
	drawCube(ft);
	glPopMatrix(); /// restore
}

/// Hexagonal prism
void drawPrism(int sides, int rt, int ft) {
	GLenum gt = (ft ? GL_POLYGON : GL_LINE_LOOP);
	float ang = 0;
	/// Top side
	glBegin(gt);
	for (int i = 0; i < sides; i++) {
		ang = i*2*M_PI/sides + rt*M_PI/2;
		glVertex3f(cos(ang), sin(ang), 1);
	}
	glEnd();
	/// Bottom side
	glBegin(gt);
	for (int i = 0; i < sides; i++) {
		ang = -i*2*M_PI/sides + rt*M_PI/2;
		glVertex3f(cos(ang), sin(ang), -1);
	}
	glEnd();
	/// Sides
	for (int i = 0; i < sides; i++) {
		glBegin(gt);
		ang = i*2*M_PI/sides + rt*M_PI/2;
		glVertex3f(cos(ang), sin(ang),  1);
		glVertex3f(cos(ang), sin(ang), -1);
		ang = (i+1)*2*M_PI/sides + rt*M_PI/2;
		glVertex3f(cos(ang), sin(ang), -1);
		glVertex3f(cos(ang), sin(ang),  1);
		glEnd();
	}
}

/// Element
void drawElement(int vc, int ft) {
	if (vc==4)
		drawCube(ft);
	else
		drawPrism(6,1,ft);
}

/// Length of vector
double veclen(double x, double y, double z) {
	return sqrt(x*x + y*y + z*z);
}

/// Angle in radians between two vectors
double vecangle(double ax, double ay, double az,
				double bx, double by, double bz) {
	return acos( (ax*bx + ay*by + az*bz) / (veclen(ax,ay,az) * veclen(bx,by,bz)) );
}

/// Dot product
double dotprod(double ax, double ay, double az,
				double bx, double by, double bz) {
	return veclen(ax,ay,az) * veclen(bx,by,bz) * cos(vecangle(ax,ay,az, bx,by,bz));
}

/// Cross product
struct vec crossprod(double ax, double ay, double az,
				double bx, double by, double bz) {
	struct vec v;
	v.x =   ay*bz - az*by;
	v.y = -(ax*bz - az*bx);
	v.z =   ax*by - ay*bx;
	return v;
}

/// Rodrigues' rotation formula - rotate (vx,vy,vz) around (rx,ry,rz) with angle theta in radians
struct vec vecrot(double vx, double vy, double vz,
				double rx, double ry, double rz, double theta) {
	struct vec v;
	struct vec c = crossprod(vx,vy,vz, rx,ry,rz);
	double d = dotprod(vx,vy,vz, rx,ry,rz);
	v.x = vx*cos(theta) + c.x*sin(theta) + rx*d*(1.0-cos(theta));
	v.y = vy*cos(theta) + c.y*sin(theta) + ry*d*(1.0-cos(theta));
	v.z = vz*cos(theta) + c.z*sin(theta) + rz*d*(1.0-cos(theta));
	return v;
}

/// MyWindow - draw
/// https://www.khronos.org/registry/OpenGL-Refpages/gl2.1/
/// GL_POINTS, GL_LINES, GL_LINE_STRIP, GL_LINE_LOOP
/// GL_TRIANGLES, GL_TRIANGLE_STRIP, GL_TRIANGLE_FAN
/// GL_QUADS, GL_QUAD_STRIP, GL_POLYGON
void MyWindow::draw() {
	
	/// Viewport
	glViewport(0, 0, pixel_w(), pixel_h());
	
	/// Depth test
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glDepthRange(0, 1);
	
	/// Culling
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CCW);
	
	/// Color alpha
	///glEnable(GL_ALPHA_TEST);
	///glAlphaFunc(GL_GREATER, 0.5);
	
	/// Clear screen - set color before clearing
	glClearColor((backclr ? 1 : 0.3), (backclr ? 1 : 0.3), (backclr ? 1 : 0.3), 0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	/// Rotate before movement
	struct vec v;
	v.x = v.y = v.z = 0;
	/// Plane Oxy
	if (kbd == 21) { /// shift+d
		v = vecrot(locX-eyeX,locY-eyeY,locZ-eyeZ, 0,0,1, convtorad(180+theta));
		eyeX = locX+v.x; eyeY = locY+v.y; ///eyeZ = -v.z;
	} else if (kbd == 22) { /// shift+a
		v = vecrot(locX-eyeX,locY-eyeY,locZ-eyeZ, 0,0,1, convtorad(180-theta));
		eyeX = locX+v.x; eyeY = locY+v.y; ///eyeZ = -v.z;
	}
	/// Plane Oxz
	else if (kbd == 23) { /// shift+w
		v = vecrot(locX-eyeX,locY-eyeY,locZ-eyeZ, 0,1,0, convtorad(180+theta));
		eyeX = locX+v.x; eyeZ = locZ+v.z;
	} else if (kbd == 24) { /// shift+s
		v = vecrot(locX-eyeX,locY-eyeY,locZ-eyeZ, 0,1,0, convtorad(180-theta));
		eyeX = locX+v.x; eyeZ = locZ+v.z;
	}
	/// Plane Oyz
	else if (kbd == 25) { /// shift+e
		v = vecrot(locX-eyeX,locY-eyeY,locZ-eyeZ, 1,0,0, convtorad(180+theta));
		eyeY = locY+v.y; eyeZ = locZ+v.z;
	} else if (kbd == 26) { /// shift+q
		v = vecrot(locX-eyeX,locY-eyeY,locZ-eyeZ, 1,0,0, convtorad(180-theta));
		eyeY = locY+v.y; eyeZ = locZ+v.z;
	}
	/// Clear flags
	if (kbd >= 21 && kbd <= 26)
		kbd = msb = msw = 0;
	
	/// Calculate movement angles
	double alpha = vecangle(locX-eyeX,locY-eyeY,locZ-eyeZ, 1,0,0);
	double beta  = vecangle(locX-eyeX,locY-eyeY,locZ-eyeZ, 0,1,0);
	double gamma = vecangle(locX-eyeX,locY-eyeY,locZ-eyeZ, 0,0,1);
	
	double tr1 = acc * cos(alpha);
	double tr2 = acc * cos(beta);
	double tr3 = acc * cos(gamma);
	
	int asgn = 1;
	int bsgn = 1;
	if (alpha >= convtorad(90) && beta >= convtorad(90))    asgn = bsgn = -1;
	else if (alpha > convtorad(90) && beta < convtorad(90))	bsgn = -1;
	else if (alpha < convtorad(90) && beta > convtorad(90))	asgn = -1;
	
	double rt1 = acc * asgn*cos(alpha-convtorad(90));
	double rt2 = acc * bsgn*cos(beta -convtorad(90));
	double rt3 = acc *      cos(gamma-convtorad(90));
	
	/// Keyboard
	if (kbd == 11) { /// d
		eyeX += rt1; eyeY -= rt2;
		locX += rt1; locY -= rt2;
	} else if (kbd == 12) { /// a
		eyeX -= rt1; eyeY += rt2;
		locX -= rt1; locY += rt2;
	} else if (kbd == 13) { /// w
		eyeX += tr1; eyeY += tr2;
		locX += tr1; locY += tr2;
	} else if (kbd == 14) { /// s
		eyeX -= tr1; eyeY -= tr2;
		locX -= tr1; locY -= tr2;
	} else if (kbd == 15) { /// e
		eyeZ += acc;
		locZ += acc;
	} else if (kbd == 16) { /// q
		eyeZ -= acc;
		locZ -= acc;
	}
	/// Zoom in-out
	else if (kbd == 17 || msw == -1) { /// z
		eyeX += tr1; eyeY += tr2; eyeZ += tr3;
		locX += tr1; locY += tr2; locZ += tr3;
	} else if (kbd == 18 || msw == 1) { /// x
		eyeX -= tr1; eyeY -= tr2; eyeZ -= tr3;
		locX -= tr1; locY -= tr2; locZ -= tr3;
	}
	/// Mouse
	else if (msb == 31) { /// d+w
		eyeZ += rt3;
		locZ += rt3;
	} else if (msb == 32) { /// a+s
		eyeZ -= rt3;
		locZ -= rt3;
	} else if (msb == 33) { /// d+s
		eyeX += rt1; eyeY -= rt2;
		locX += rt1; locY -= rt2;
	} else if (msb == 34) { /// a+w
		eyeX -= rt1; eyeY += rt2;
		locX -= rt1; locY += rt2;
	}
	/// Clear flags
	kbd = msb = msw = 0;
	
	/// Projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (1.0*pixel_w())/(1.0*pixel_h()), 0.01, 100.0);
	
	/// Model-View matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	/// View commands
	
	/// Camera eye, Location of origin, Up vector
	gluLookAt(eyeX,eyeY,eyeZ, locX,locY,locZ, 0,0,1);
	
	/// Model commands - translate * rotate * scale * vertex
	
	/// Wireframe
	int ft = !wireframe;
	int ch = crosshair;
	int vc = vcell;
	
	/// Objects
	for (int xc = 0; xc < xel; xc++) {
		for (int yc = 0; yc < yel; yc++) {
			for (int zc = 0; zc < zel; zc++) {
				
				/// Duplicate matrix
				glPushMatrix();
				
				/// Change drawing origin
				glTranslatef((xc+1)*1.5, (yc+1)*1.5, (zc+1)*1.5);
				///drawCrosshair(0,0,0,ch);
				///drawCluster(ft);
				glScalef(0.4,0.4,0.4);
				
				/// Color
				glColor3f(0.3,0.7,0.5);
				
				/// Cube
				drawElement(vc,ft);
				
				/// Outline
				glColor3f(1,1,1);
				glScalef(1.01,1.01,1.01);
				drawElement(vc,0);
				
				/// Marker
				if (xc==xmark && yc==ymark && zc==zmark) {
					glColor3f((backclr?0:1),(backclr?0:1),0);
					glScalef(1.08,1.08,1.08);
					drawElement(vc,0);
					glScalef(1.09,1.09,1.09);
					drawElement(vc,0);
					glScalef(1.10,1.10,1.10);
					drawElement(vc,0);
				}
				
				/// Restore matrix
				glPopMatrix();
				
			}
		}
	}
	
	/// Mark circle
	if (circle1)
		for (int phi = 0; phi <= 180; phi+=15)
			drawCrosshair(locX+2.7*cos(convtorad(phi)),locY+2.7*sin(convtorad(phi)),locZ, ch); /// Oxy
	if (circle2)
		for (int phi = 0; phi <= 180; phi+=15)
			drawCrosshair(locX+2.7*cos(convtorad(phi)),locY,locZ+2.7*sin(convtorad(phi)), ch); /// Oxz
	if (circle3)
		for (int phi = 0; phi <= 180; phi+=15)
			drawCrosshair(locX,locY+2.7*cos(convtorad(phi)),locZ+2.7*sin(convtorad(phi)), ch); /// Oyz
	
	/// Crosshair in front
	drawCrosshair(locX,locY,locZ, ch);
	
	/// Final calculations are: Projection * View * Model * Vertex
	/// gluPerspective * gluLookAt * (translate*rotate*scale) * vertex
	
}

