/// MyGL header

#include <FL/Fl_Gl_Window.H>

class MyWindow : public Fl_Gl_Window {
	private:
		void draw();
		int handle(int event);
		
		int mX   = 0;        /// mouse position X
		int mY   = 0;        /// mouse position Y
		int mDX  = 0;        /// mouse delta X
		int mDY  = 0;        /// mouse delta Y
		int mpix = 1;        /// mouse pixels
		
		int crosshair = 0;   /// crosshair
		int wireframe = 0;   /// wireframe
		int backclr   = 1;   /// background
		int scrinfo   = 0;   /// information
		int circle1   = 0;   /// circle Oxy
		int circle2   = 0;   /// circle Oxz
		int circle3   = 0;   /// circle Oyz
		
		double acc  =  0.5;  /// movement accuracy
		double eyeX =  5.0;  /// camera eye X
		double eyeY =  2.0;  /// camera eye Y
		double eyeZ = 20.0;  /// camera eye Z
		double locX =  5.0;  /// look at origin X
		double locY =  2.01; /// look at origin Y
		double locZ = 15.0;  /// look at origin Z
		
		int kbd = 0;         /// keyboard flag
		int msb = 0;         /// mouse button flag
		int msw = 0;         /// mouse wheel flag
		double theta = 15.0; /// rotation angle
		
		double** wdata;      /// matrix data
		int      wsize;      /// matrix size
		
		double lima  = 0.75; /// limit alpha
		double limb  = 0.25; /// limit beta
		int    pclrs = 1;    /// point colors
		double psize = 0.2;  /// point size
		
	public:
		MyWindow(int x, int y, int w, int h, const char* lbl);
		void myPlotData(double** wd, int ws);
		void myLimitA(double a);
		void myLimitB(double b);
		void myPlotClrs(int v);
		void myPlotSize(double v);
};

