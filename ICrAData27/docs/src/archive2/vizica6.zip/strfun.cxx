/// String functions

#include "vizica.h"
#include "zerofun.h"

/// Buffers
char* elembuff = (char*) malloc(sizeof(char) * 256);

/// Show string raw data
void stringShowRaw(char* start, char* end) {
	for ( ; start < end; start++)
		printf("%d ", *start);
}

/// Replace line endings from Win \r\n and Mac \r to UNIX \n
void stringLineEnd(char* str) {
	for ( ; *str; str++)
		if (*str == '\r')
			*str = (*(str+1) == '\n' ? ' ' : '\n');
}

/// Count characters in string
int stringCountChar(char* start, char* end, char ch) {
	int cc = 0;
	for ( ; start < end; start++)
		if (*start == ch)
			cc++;
	
	return cc;
}

/// Trim spaces and tabs, return pointer to first character
/**char* stringTrimLine(char* str) {
	char* end = str+strlen(str)-1;
	
	while (*str == ' ' || *str == '\t')
		*str++ = '\0';
	while (*end == ' ' || *end == '\t')
		*end-- = '\0';
	
	return (str < end ? str : end);
}**/
/// Also clear ; , from both sides of each line
char* stringTrimLine(char* str) {
	char* end = str+strlen(str)-1;
	
	while (*str == ' ' || *str == '\t' || *str == ';' || *str == ',')
		*str++ = '\0';
	while (*end == ' ' || *end == '\t' || *end == ';' || *end == ',')
		*end-- = '\0';
	
	return (str < end ? str : end);
}

/// Clear comments
void stringClearComments(char* str, char ch) {
	for ( ; *str; str++)
		if (*str == ch)
			while (*str != '\0')
				*str++ = '\0';
}

/// Save the address of the character after each \n
/// Replace \n with \0, therefore this function returns array of pointers to char*
char** strArrMake(char* str, int flines) {
	
	char** arrF = (char**) malloc(sizeof(char*) * flines);
	int k = 0;
	arrF[k++] = str;
	
	//printf("arrF %d %d\n", 0, *arrF[0]);	
	while (*str) {
		if (*str == '\n') {
			*str = '\0';
			arrF[k++] = ++str;
		} else
			str++;
	}
	
	return (k == flines ? arrF : NULL);
}

/// Show string array
void strArrShow(char** arrF, int flines) {
	for (int i = 0; i < flines; i++)
		printf("%p %d |%s|\n", arrF[i], i, arrF[i]);
}

/// Array trim line
void strArrTrim(char** arrF, int flines) {
	for (int i = 0; i < flines; i++)
		if (strlen(arrF[i]) > 0)
			arrF[i] = stringTrimLine(arrF[i]);
}

/// Array clear comments
void strArrComments(char** arrF, int flines, char ch) {
	for (int i = 0; i < flines; i++)
		if (strlen(arrF[i]) > 0)
			stringClearComments(arrF[i], ch);
}

/// Line element
double dataElem(char* start, int ind, char sep) {
	char* end = start+strlen(start);
	char* pos = start;
	int cc = 0;
	
	for ( ; pos <= end; pos++) {
		if (*pos == sep || *pos == '\0') {
			
			if (cc == ind) {
				int vlen = pos-start;
				if (vlen > 0 && vlen < 255) {
					for (int i = 0; i < vlen; i++)
						elembuff[i] = *start++;
					elembuff[vlen] = '\0';
					
					//printf("%d|%s|\n", vlen, elembuff);
					return atof(elembuff);
				} else
					return 0;
			}
			
			start = pos+1;
			cc++;
		}
	}
	
	return 0x32DCD5;
}

/// String header
char* dataHead(char* start, int ind, char sep) {
	char* end = start+strlen(start);
	char* pos = start;
	int cc = 0;
	
	for ( ; pos <= end; pos++) {
		if (*pos == sep || *pos == '\0') {
			
			if (cc == ind) {
				int vlen = pos-start;
				if (vlen > 0 && vlen < 255) {
					for (int i = 0; i < vlen; i++)
						elembuff[i] = *start++;
					elembuff[vlen] = '\0';
					
					//printf("%d|%s|\n", vlen, elembuff);
					return elembuff;
				} else
					return 0;
			}
			
			start = pos+1;
			cc++;
		}
	}
	
	elembuff[0] = elembuff[1] = elembuff[2] = '-';
	elembuff[3] = '\0';
	return elembuff;
}

/// Open file and save contents as char*
char* openFile(const char* fname) {
	
	/// Open file
	FILE* fptr = fopen(fname, "rb");
	if (fptr == NULL)
		return NULL;
	
	/// Seek to end to find file size
	fseek(fptr, 0, SEEK_END);
	int flen = ftell(fptr);
	rewind(fptr);
	
	/// Read file in char array
	char* fbuf = (char*) malloc(sizeof(char) * (flen+1));
	int fch = fread(fbuf, sizeof(char), flen, fptr);
	if (fch != flen)
		fbuf[0] = '\0';
	
	/// Close string
	fbuf[flen] = '\0';
	
	/// Close file
	fclose(fptr);
	
	return fbuf;
}

int colCount(int* indC, int size) {
	
	int cols = 0;
	for (int i = 0; i < size; i++)
		if (cols < indC[i])
			cols = indC[i];
	
	return cols;
}

/// Read file and return struct
struct vizread readFile(const char* fname, char sep, int hdr) {
	
	/// String data
	char* fbuf = openFile(fname);
	//stringShowRaw(fbuf, fbuf+strlen(fbuf)+1);
	
	/// Replace line endings
	stringLineEnd(fbuf);
	//stringShowRaw(fbuf, fbuf+strlen(fbuf)+1);
	
	/// Count new line characters
	int flines = stringCountChar(fbuf, fbuf+strlen(fbuf)+1, '\n')+1;
	//printf("lines %d\n", flines);
	
	/// Make string array
	char** arrF = strArrMake(fbuf, flines);
	//strArrShow(arrF, flines);
	
	/// Trim each line
	strArrTrim(arrF, flines);
	
	/// Parsing of # directives here
	
	/// Clear # comments
	strArrComments(arrF, flines, '#');
	
	printf("\narrF\n");
	strArrShow(arrF, flines);
	
	
	/// Number of rows
	int rows = 0;
	for (int i = 0; i < flines; i++)
		if (strlen(arrF[i]) > 0)
			rows++;
	rows -= hdr;
	
	/// New string array with data lines only
	char** arrD = (char**) malloc(sizeof(char*) * rows);
	int cc = 0;
	for (int i = 0; i < flines; i++)
		if (strlen(arrF[i]) > 0)
			arrD[cc++] = arrF[i];
	
	printf("\narrD\n");
	strArrShow(arrD, rows);
	
	/// Number of columns
	int* indC = (int*) malloc(sizeof(int) * rows);
	zeroIntArray(indC, rows);
	for (int i = 0; i < rows; i++)
		indC[i] = stringCountChar(arrD[i], arrD[i]+strlen(arrD[i]), sep)+1;
	
	int cols = colCount(indC, rows);
	cols -= hdr;
	
	printf("\nrows %d   cols %d\n", rows, cols);
	
	/// Allocate matrix
	double** matW = (double**) malloc(sizeof(double*) * rows);
	for (int i = 0; i < rows; i++)
		matW[i] = (double*) malloc(sizeof(double) * cols);
	zeroDoubleMatrix(matW, rows, cols);
	
	for (int i = 0; i < rows; i++)
		for (int j = 0; j < cols; j++)
			matW[i][j] = dataElem(arrD[i+hdr], j+hdr, sep);
	
	printf("\nmatW\n");
	showDoubleMatrix(matW, rows, cols);
	
	/// Headers
	char** rhead = (char**) malloc(sizeof(char*) * rows);
	for (int i = 0; i < rows; i++)
		rhead[i] = (char*) malloc(sizeof(char) * 256);
	
	char** chead = (char**) malloc(sizeof(char*) * cols);
	for (int j = 0; j < cols; j++)
		chead[j] = (char*) malloc(sizeof(char) * 256);
	
	if (hdr) {
		for (int i = 0; i < rows; i++)
			//char* fff = dataHead(arrD[i+hdr], 0);
			//memcpy(rhead[i], fff, strlen(fff));
			strcpy(rhead[i], dataHead(arrD[i+hdr], 0, sep));
			//printf("rhead %s\n", dataHead(arrD[i+hdr], 0));
		
		for (int j = 0; j < cols; j++)
			strcpy(chead[j], dataHead(arrD[0], j+hdr, sep));
			//printf("chead %s\n", dataHead(arrD[0], j+hdr));
	} else {
		for (int i = 0; i < rows; i++) {
			sprintf(elembuff, "R%d", (i+1));
			strcpy(rhead[i], elembuff);
		}
		for (int j = 0; j < cols; j++) {
			sprintf(elembuff, "C%d", (j+1));
			strcpy(chead[j], elembuff);
		}
	}
	
	/// Debug
	for (int i = 0; i < rows; i++)
		printf("rhead %s\n", rhead[i]);
	for (int j = 0; j < cols; j++)
		printf("chead %s\n", chead[j]);
	
	
	/*int** indC = (int**) malloc(sizeof(int*) * rows);
	for (int i = 0; i < rows; i++)
		indC[i] = (int*) malloc(sizeof(int) * 3);
	zeroIntMatrix(indC, rows, 3);
	
	for (int i = 0; i < flines; i++){
		if (strlen(arrF[i]) > 0) {
			indC[cc][0] = stringCountChar(arrF[i], arrF[i]+strlen(arrF[i]), '\t');
			indC[cc][0] = stringCountChar(arrF[i], arrF[i]+strlen(arrF[i]), ';');
			indC[cc][0] = stringCountChar(arrF[i], arrF[i]+strlen(arrF[i]), ',');
			
			stringShowRaw(arrF[i], arrF[i]+strlen(arrF[i]));
			printf("cols %d\n", stringCountChar(arrF[i], arrF[i]+strlen(arrF[i]), '\t'));
		}
	}*/
	
	/// Result
	struct vizread res;
	res.matW = matW;
	res.rows = rows;
	res.cols = cols;
	res.rhead = rhead;
	res.chead = chead;
	
	return res;
}

