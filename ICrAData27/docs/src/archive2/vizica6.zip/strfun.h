/// String functions header

struct vizread readFile(const char* fname, char sep, int hdr);

