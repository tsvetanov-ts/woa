/**
 * 
 * VizicA
 * 
 * Author: Nikolay Ikonomov
 * Version: alpha17
 * Date: December 27, 2019
 * Compiled by: GCC 7.3.0 (Linux), TDM-GCC 5.1.0 (Win32/Win64)
 * 
 */

/// FLTK uses WIN32 flag
#if defined(_WIN32) && !defined(WIN32)
#define WIN32
#endif

#include <FL/gl.h>
#include <FL/glu.h>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Gl_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Text_Buffer.H>
#include <FL/Fl_Text_Display.H>

#include <FL/Fl_Tile.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Menu_Item.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Spinner.H>

#include <FL/Fl_Table_Row.H>

#include <FL/Fl_File_Chooser.H>
#include <FL/fl_draw.H>
#include <png.h>

#include "vizica.h"
#include "strfun.h"
#include "icra.h"
#include "zerofun.h"

/// Global variables
Fl_Window* mainWin;
Fl_Choice* chSep;
Fl_Choice* chVar;
Fl_Choice* chMth;
Fl_Check_Button* chHdr;
Fl_Check_Button* chTr;
Fl_Spinner* chMatCnt;
Fl_Text_Buffer* buffMsg;

/// Buffers
time_t* ttbuff = (time_t*) malloc(sizeof(time_t));
char* timebuff = (char*) malloc(sizeof(char) * 32);
char* filebuff = (char*) malloc(sizeof(char) * 256);
char* strbuff  = (char*) malloc(sizeof(char) * 256);
char* msgbuff  = (char*) malloc(sizeof(char) * 256);

struct vizfile vfile;
struct vizdata vdata;
struct vizres vres;



/// MyTable
class MyTable : public Fl_Table_Row {
	private:
		double** wdata;
		int      wsize;
		char**   rhead;
		int      rsize;
		char**   chead;
		int      csize;
	protected:
		void draw_cell(TableContext context, int r=0, int c=0, int x=0, int y=0, int w=0, int h=0);
	public:
		MyTable(int x, int y, int w, int h, const char* lbl);
		void myCellData(double** wd, int ws, char** wrh, int wrs, char** wch, int wcs);/* {
			wdata = wd;
			wsize = ws;
			rhead = wrh;
			rsize = wrs;
			chead = wch;
			csize = wcs;
		}*/
};

MyTable* tableA;

/// MyTable - cell data
void MyTable::myCellData(double** wd, int ws, char** wrh, int wrs, char** wch, int wcs) {
	wdata = wd;
	wsize = ws;
	rhead = wrh;
	rsize = wrs;
	chead = wch;
	csize = wcs;
}

/// MyTable - constructor
MyTable::MyTable(int x, int y, int w, int h, const char* lbl) : Fl_Table_Row(x, y, w, h, lbl) {
	/// no data
	myCellData(NULL, -1, NULL, -1, NULL, -1); /// this must be first line
	rows(0);
	cols(0);
	/// table
	box(FL_DOWN_FRAME);
	color(FL_WHITE);
	table_box(FL_NO_BOX);
	selection_color(FL_YELLOW);
	/// rows
	row_resize(1);
	row_resize_min(5);
	row_height_all(20);
	row_header(1);
	row_header_width(80);
	/// cols
	col_resize(1);
	col_resize_min(5);
	col_width_all(80);
	col_header(1);
	col_header_height(25);
}

/// MyTable - draw cell
void MyTable::draw_cell(TableContext context, int r, int c, int x, int y, int w, int h) {
	
	static char scell[42];
	static char srhead[256];
	static char schead[256];
	sprintf(scell, "---");
	sprintf(srhead, "---");
	sprintf(schead, "---");
	
	if (wsize > 0) {
		if (r != c)
			snprintf(scell, 40, "%.4f", wdata[r][c]);
	} else
		sprintf(scell, "%d/%d", r, c);
	
	if (rsize > 0 && r < rsize)
		snprintf(srhead, 255, "%s", rhead[r]);
	else
		sprintf(srhead, "row%d", r);
	
	if (csize > 0 && c < csize)
		snprintf(schead, 255, "%s", chead[c]);
	else
		sprintf(schead, "col%d", c);
	
	switch (context) {
	case CONTEXT_STARTPAGE:
		fl_font(FL_HELVETICA, 14);
		return;
	case CONTEXT_ROW_HEADER:
		fl_push_clip(x,y,w,h);
			fl_draw_box(FL_THIN_UP_BOX, x,y,w,h, row_header_color());
			fl_color(FL_BLACK);
			fl_draw(srhead, x,y,w,h, FL_ALIGN_CENTER);
		fl_pop_clip();
		return;
	case CONTEXT_COL_HEADER:
		fl_push_clip(x,y,w,h);
			fl_draw_box(FL_THIN_UP_BOX, x,y,w,h, col_header_color());
			fl_color(FL_BLACK);
			fl_draw(schead, x,y,w,h, FL_ALIGN_CENTER);
		fl_pop_clip();
		return;
	case CONTEXT_CELL:
		fl_push_clip(x,y,w,h);
			/// cell background
			fl_color(row_selected(r) ? selection_color() : FL_WHITE);
			fl_rectf(x,y,w,h); /// rectangle fill
			/// cell contents
			fl_color(row_selected(r) ? FL_BLUE : FL_BLACK);
			fl_draw(scell, x,y,w,h, FL_ALIGN_RIGHT);
			/// cell border
			fl_color(FL_GRAY);
			fl_rect(x,y,w,h); /// no fill
		fl_pop_clip();
		return;
	default:
		return;
	}
}

/// Free vfile
void freevfile() {
	if (vfile.fbuf != NULL && vfile.buf > 0) {
		free(vfile.fbuf);
		vfile.buf = -1;
	}
	if (vfile.arrF != NULL && vfile.flines > 0) {
		free(vfile.arrF);
		vfile.flines = -1;
	}
}

/// Free vdata
void freevdata() {
	if (vdata.matW != NULL && vdata.rW > 0) {
		for (int i = 0; i < vdata.rW; i++)
			free(vdata.matW[i]);
		free(vdata.matW);
		vdata.rW = vdata.cW = -1;
	}
	if (vdata.rhead != NULL && vdata.rsize > 0) {
		for (int i = 0; i < vdata.rsize; i++)
			free(vdata.rhead[i]);
		free(vdata.rhead);
		vdata.rsize = -1;
	}
	if (vdata.chead != NULL && vdata.csize > 0) {
		for (int i = 0; i < vdata.csize; i++)
			free(vdata.chead[i]);
		free(vdata.chead);
		vdata.csize = -1;
	}
}

/// Free vres
void freevres() {
	if (vres.matR != NULL && vres.size > 0) {
		for (int i = 0; i < vres.size; i++)
			free(vres.matR[i]);
		free(vres.matR);
		vres.size = -1;
	}
}

/// Message
void msg(const char* m) {
	time(ttbuff);
	strftime(timebuff, 32, "%H:%M:%S", localtime(ttbuff));
	sprintf(msgbuff, "%s %s\n", timebuff, m);
	buffMsg->append(msgbuff);
}

/// Listen for clean
void listenClean(Fl_Widget* wdj, void* ptr) {
	/// Clear table first
	tableA->clear();
	tableA->myCellData(NULL, -1, NULL, -1, NULL, -1);
	/// Clear global data
	freevfile();
	freevdata();
	freevres();
	/// Clear messages
	buffMsg->remove(0, buffMsg->length());
	msg("VizicA");
}

/// Listen for method change
void listenMethod(Fl_Widget* wdj, void* ptr) {
	int val = int( ((Fl_Choice*) wdj)->value() );
	if (val == 0) {
		chMatCnt->value(1);
		chHdr->activate();
		chTr->activate();
		chMatCnt->deactivate();
	} else {
		chHdr->value(0);
		chTr->value(0);
		chHdr->deactivate();
		chTr->deactivate();
		chMatCnt->activate();
	}
}

/// Listen for open file
void listenOpen(Fl_Widget* wdj, void* ptr) {
	
	/// --- FL/Fl_File_Chooser.H @line238
	/// --- src/fl_file_dir.cxx @line89
	const char* fn = fl_file_chooser("Open file", "*", NULL, 0);
	if (fn == NULL)
		return;
	
	/// Open file
	char* fbuf = openFile(fn);
	if (fbuf == NULL) {
		msg("Could not open file");
		return;
	} else if (strlen(fbuf) <= 0) {
		msg("File has zero length");
		free(fbuf);
		return;
	} else {
		sprintf(strbuff, "File opened (%d bytes) %s", (int)strlen(fbuf), fn);
		msg(strbuff);
	}
	
	/// Free resources
	freevfile();
	
	/// Load file
	vfile = loadFile(fbuf);
	
	if (vfile.flines == -4) {
		msg("File should have at least 4 rows");
		return;
	}
	
	if (vfile.sep == 0 || vfile.sep == 1 || vfile.sep == 2)
		chSep->value(vfile.sep);
	if (vfile.hdr == 0 || vfile.hdr == 1)
		chHdr->value(vfile.hdr);
	if (vfile.tr == 0 || vfile.tr == 1)
		chTr->value(vfile.tr);
	
	if (vfile.icavar >= 1 && vfile.icavar <= 5)
		chVar->value(vfile.icavar-1);
	if (vfile.icamth >= 1 && vfile.icamth <= 5) {
		chMth->value(vfile.icamth-1);
		listenMethod(chMth, NULL);
	}
	if (vfile.matcnt >= 1 && vfile.matcnt <= 9999)
		chMatCnt->value(vfile.matcnt);
	
	sprintf(strbuff, "File loaded (%d lines)", vfile.flines);
	msg(strbuff);
}

/// Listen for save file
void listenSave(Fl_Widget* wdj, void* ptr) {
	
	if (vfile.flines == -1) {
		msg("Nothing to save");
		return;
	}
	
	/// --- FL/Fl_File_Chooser.H @line238
	/// --- src/fl_file_dir.cxx @line89
	const char* fn = fl_file_chooser("Save file", "*", NULL, 0);
	if (fn == NULL)
		return;
	
	int s = saveFile(fn, vfile, chSep->value(), chHdr->value(), chTr->value(),
		chVar->value()+1, chMth->value()+1, chMatCnt->value());
	
	if (s == -2) {
		msg("Could not save file");
		return;
	}
	
	if (s == 0 || s == 1 || s == 2)
		vfile.sep = s;
	
	sprintf(strbuff, "File saved (%d lines) %s", vfile.flines, fn);
	msg(strbuff);
}

/// Listen for calculations
void listenCalc(Fl_Widget* wdj, void* ptr) {
	
	if (vfile.flines == -1) {
		msg("No data to calculate");
		return;
	}
	
	/// Clear result
	tableA->clear();
	tableA->rows(0);
	tableA->cols(0);
	tableA->myCellData(NULL, -1, NULL, -1, NULL, -1);
	
	/// Free resources
	freevdata();
	
	/// Read file
	vdata = readFile(vfile, chSep->value(), chHdr->value(), chTr->value());
	
	if (vdata.rW == -5) {
		msg("All column sizes per row must match (including the header)");
		return;
	}
	
	if (vdata.rW == -3) {
		msg("Minimum matrix size is 3x3");
		return;
	}
	
	//printf("\nmatW\n");
	//showDoubleMatrix(vdata.matW, vdata.rW, vdata.cW);
	
	if (chMth->value() > 0) {
		if (chMatCnt->value() < 3) {
			msg("Non-standard methods require at least 3 matrices");
			return;
		}
		
		if ((double)vdata.rW/(int)chMatCnt->value() < 3.0) {
			sprintf(strbuff, "Each matrix must have at least 3 rows: %d/%d=%.6f",
				vdata.rW, (int)chMatCnt->value(), (double)vdata.rW/chMatCnt->value());
			msg(strbuff);
			return;
		}
		
		if (vdata.rW % (int)chMatCnt->value() != 0) {
			sprintf(strbuff, "Matrix rows must be fully divisible by matrix count: %d/%d=%.6f",
				vdata.rW, (int)chMatCnt->value(), (double)vdata.rW/chMatCnt->value());
			msg(strbuff);
			return;
		}
		
		sprintf(strbuff, "Matrix rows: %d/%d=%.6f",
			vdata.rW, (int)chMatCnt->value(), (double)vdata.rW/chMatCnt->value());
		msg(strbuff);
	}
	
	/// Free resources
	freevres();
	
	/// Make ICrA
	vres = makeICrA(vdata.matW, vdata.rW, vdata.cW, chVar->value()+1, chMth->value()+1, chMatCnt->value());
	
	/*if (vres.size == -7 || vres.size == -8) {
		msg("Matrix rows must be fully divisible by matrix count");
		return;
	} else if (vres.size == -9) {
		msg("Invalid method value");
		return;
	}*/
	
	printf("\nmatR\n");
	showDoubleMatrix(vres.matR, vres.size, vres.size);
	
	/// View result
	tableA->clear();
	tableA->rows(vres.size);
	tableA->cols(vres.size);
	if (chTr->value()) /// transpose
		tableA->myCellData(vres.matR, vres.size, vdata.chead, vdata.csize, vdata.rhead, vdata.rsize);
	else /// normal
		tableA->myCellData(vres.matR, vres.size, vdata.rhead, vdata.rsize, vdata.chead, vdata.csize);
	
	msg("Success");
}

/// Close window
void listenClose(Fl_Widget* wdj, void* ptr) {
	((Fl_Window*)ptr)->hide();
}

/// Exit application
void listenExit(Fl_Widget* wdj, void* ptr) {
	exit(0);
}

/// Exit window
void listenExitWin() {
	
	Fl_Window* exitWin = new Fl_Window(
		mainWin->x()+mainWin->w()/2-125, mainWin->y()+mainWin->h()/2-45,
		250, 90, "Exit");
	exitWin->color(FL_WHITE);
	
	Fl_Box* msgText = new Fl_Box(10, 20, 10, 10, "Exit the application?");
	msgText->align(FL_ALIGN_RIGHT);
	msgText->box(FL_NO_BOX);
	
	Fl_Button* btnExit = new Fl_Button(20, 50, 100, 25, "Exit");
	btnExit->color(FL_WHITE);
	btnExit->callback(listenExit, exitWin);
	
	Fl_Button* btnClose = new Fl_Button(130, 50, 100, 25, "Cancel");
	btnClose->color(FL_WHITE);
	btnClose->callback(listenClose, exitWin);
	
	exitWin->set_modal();
	exitWin->end();
	exitWin->show();
}

/// Listen for exit
void listenExit_(Fl_Widget* wdj, void* ptr) {
	listenExitWin();
}

/// Constructor
int main(int argc, char* argv[]) {
	
	/// Window
	mainWin = new Fl_Window(1200, 600, "VizicA");
	
	/// Tiles
	Fl_Tile* tile = new Fl_Tile(0, 0, 1200, 600, NULL);
	
	Fl_Group* panel1 = new Fl_Group(0, 0, 400, 190, NULL);
	panel1->box(FL_DOWN_BOX);
	panel1->color(FL_WHITE);
	
	Fl_Button* btnOpen = new Fl_Button(10, 10, 120, 25, "Open");
	btnOpen->tooltip("Open file. Parameters will be loaded if #vizica line is present in the file.");
	btnOpen->color(FL_WHITE);
	btnOpen->callback(listenOpen, btnOpen);
	
	Fl_Button* btnSave = new Fl_Button(10+120+10, 10, 120, 25, "Save");
	btnSave->tooltip("Save file. The selected parameters will be saved in #vizica line in the file.");
	btnSave->color(FL_WHITE);
	btnSave->callback(listenSave, btnSave);
	
	Fl_Button* btnClean = new Fl_Button((10+120)*2+10, 10, 120, 25, "Clean");
	btnClean->tooltip("Release all working memory used by the application.");
	btnClean->color(FL_WHITE);
	btnClean->callback(listenClean, btnClean);
	
	Fl_Menu_Item listSep[] = {
		{"Tab \\t"},
		{"Semicolon ;"},
		{"Comma ,"},
		{0}
	};
	
	Fl_Menu_Item listVar[] = {
		{"\xce\xbc-biased"},
		{"Unbiased"},
		{"\xce\xbd-biased"},
		{"Balanced"},
		{"Weighted"},
		{0}
	};
	
	Fl_Menu_Item listMth[] = {
		{"Standard"},
		{"Aggr Average"},
		{"Aggr MaxMin"},
		{"Aggr MinMax"},
		{"Criteria Pair"},
		{0}
	};
	
	chSep = new Fl_Choice(10+120+10, 10+25+10, 120, 25, "Separator");
	chSep->tooltip("Column separator in the file.");
	chSep->menu(listSep);
	
	chVar = new Fl_Choice(10+120+10, (10+25)*2+10, 120, 25, "ICrA Variant");
	chVar->tooltip("Variant for InterCriteria Analysis. This is the base algorithm.");
	chVar->menu(listVar);
	
	chMth = new Fl_Choice(10+120+10, (10+25)*3+10, 120, 25, "ICrA Method");
	chMth->tooltip("Method for InterCriteria Analysis. Standard directly applies the base algorithm. "
		"The others require at least three input matrices.");
	chMth->menu(listMth);
	chMth->callback(listenMethod, chMth);
	
	chHdr = new Fl_Check_Button((10+120)*2+10, 10+25+10, 120, 25, "Headers");
	chHdr->tooltip("Row and column headers in the file. Applies only to Standard.");
	chHdr->value(0);
	
	chTr = new Fl_Check_Button((10+120)*2+10, (10+25)*2+10, 120, 25, "Transpose");
	chTr->tooltip("Transpose the matrix. Applies only to Standard.");
	chTr->value(0);
	
	chMatCnt = new Fl_Spinner((10+120)*2+10+60, (10+25)*3+10, 60, 25, "MatCnt");
	chMatCnt->tooltip("Matrix count is applied to Aggregated and Criteria Pair.");
	chMatCnt->minimum(1);
	chMatCnt->maximum(9999);
	chMatCnt->step(1);
	chMatCnt->value(1);
	chMatCnt->deactivate();
	
	Fl_Button* btnCalc = new Fl_Button(10, (10+25)*4+10, 400-10-10, 25, "Make Calculations");
	btnCalc->tooltip("Make the calculations and display them.");
	btnCalc->color(FL_WHITE);
	btnCalc->callback(listenCalc, btnCalc);
	
	panel1->resizable(0);
	panel1->end();
	
	Fl_Group* panel2 = new Fl_Group(0, 190, 400, 410, NULL);
	panel2->box(FL_DOWN_BOX);
	panel2->color(FL_WHITE);
	
	buffMsg = new Fl_Text_Buffer();
	buffMsg->text("");
	
	Fl_Text_Display* textMsg = new Fl_Text_Display(0, 190, 400, 410, NULL);
	textMsg->textsize(14);
	textMsg->wrap_mode(Fl_Text_Display::WRAP_AT_BOUNDS, 0);
	textMsg->buffer(buffMsg);
	
	panel2->end();
	
	Fl_Group* panel3 = new Fl_Group(400, 0, 500, 300, NULL);
	panel3->box(FL_DOWN_BOX);
	panel3->color(FL_WHITE);
	
	tableA = new MyTable(400, 0, 500, 300, NULL);
	/*tableA->box(FL_DOWN_FRAME);
	tableA->color(FL_WHITE);
	tableA->table_box(FL_NO_BOX);
	tableA->selection_color(FL_YELLOW);
	
	/// tableA rows
	tableA->rows(0);
	tableA->row_resize(1);
	tableA->row_resize_min(5);
	tableA->row_height_all(20);
	tableA->row_header(1);
	tableA->row_header_width(80);
	
	/// tableA cols
	tableA->cols(0);
	tableA->col_resize(1);
	tableA->col_resize_min(5);
	tableA->col_width_all(80);
	tableA->col_header(1);
	tableA->col_header_height(25);
	
	
	tableA->rows(0);
	tableA->cols(0);
	tableA->myCellData(NULL, -1, NULL, -1, NULL, -1);
	*/
	panel3->end();
	
	Fl_Group* panel4 = new Fl_Group(400, 300, 500, 300, NULL);
	panel4->box(FL_DOWN_BOX);
	panel4->color(FL_WHITE);
	panel4->end();
	
	Fl_Group* panel5 = new Fl_Group(900, 0, 300, 600, NULL);
	panel5->box(FL_DOWN_BOX);
	panel5->color(FL_WHITE);
	panel5->end();
	
	tile->end();
	
	/// Initialize variables
	vfile.buf = vfile.flines = -1;
	vdata.rW = vdata.cW = vdata.rsize = vdata.csize = -1;
	vres.size = -1;
	msg("VizicA");
	
	mainWin->end();
	mainWin->resizable(mainWin);
	mainWin->callback(listenExit_, mainWin);
	
	mainWin->show(argc, argv);
	return Fl::run();
}

