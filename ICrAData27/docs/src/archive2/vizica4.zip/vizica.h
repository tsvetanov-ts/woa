/// VizicA header

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>

#ifndef min
#define min(a,b) ((a) < (b) ? (a) : (b))
#endif
#ifndef max
#define max(a,b) ((a) > (b) ? (a) : (b))
#endif

/// Structs
struct vizread {
	double** matW;
	int rows;
	int cols;
	char** rhead;
	char** chead;
};

struct vizres {
	double** matR;
	int      rows;
};

