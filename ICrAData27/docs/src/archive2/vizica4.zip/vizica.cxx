/**
 * 
 * VizicA
 * 
 * Author: Nikolay Ikonomov
 * Version: alpha4
 * Date: December 14, 2019
 * Compiled by: GCC 7.3.0 (Linux), TDM-GCC 5.1.0 (Win32/Win64)
 * 
 */

#include "vizica.h"
#include "icra.h"
#include "str.h"
#include "zerofun.h"

int main() {
	
	printf("VizicA\n");
	
	int rows = 4;
	int cols = 5;
	
	double** matW = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matW[i] = (double*) malloc(sizeof(double) * cols);
	zeroDoubleMatrix(matW, rows, cols);
	
	matW[0][0] = 6; matW[0][1] = 5; matW[0][2] = 3; matW[0][3] = 7; matW[0][4] = 6;
	matW[1][0] = 7; matW[1][1] = 7; matW[1][2] = 8; matW[1][3] = 1; matW[1][4] = 3;
	matW[2][0] = 4; matW[2][1] = 3; matW[2][2] = 5; matW[2][3] = 9; matW[2][4] = 1;
	matW[3][0] = 4; matW[3][1] = 5; matW[3][2] = 6; matW[3][3] = 7; matW[3][4] = 8;
	
	printf("\nmatW\n");
	showDoubleMatrix(matW, rows, cols);
	
	struct vizres res = makeCalc(matW, NULL, rows, cols, 5, 0);
	
	printf("\nmatR\n");
	showDoubleMatrix(res.matR, res.rows, res.rows);
	
	
	readFile("ex1.csv");
	
	return 0;
}

