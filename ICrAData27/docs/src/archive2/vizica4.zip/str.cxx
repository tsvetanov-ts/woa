/// String

#include "vizica.h"

/// Buffers
char* elembuff = (char*) malloc(sizeof(char) * 256);

/// Show string raw data
void stringShowRaw(char* start, char* end) {
	for ( ; start < end; start++)
		printf("%d ", *start);
}

/// Replace line endings from Win \r\n and Mac \r to UNIX \n
void stringLineEnd(char* str) {
	for ( ; *str; str++)
		if (*str == '\r')
			*str = (*(str+1) == '\n' ? ' ' : '\n');
}

/// Count characters in string
int stringCountChar(char* start, char* end, char ch) {
	int cc = 0;
	for ( ; start < end; start++)
		if (*start == ch)
			cc++;
	
	return cc;
}

/// Trim spaces and tabs, return pointer to first character
char* stringTrimLine(char* str) {
	char* end = str+strlen(str)-1;
	
	while (*str == ' ' || *str == '\t')
		*str++ = '\0';
	while (*end == ' ' || *end == '\t')
		*end-- = '\0';
	
	return (str < end ? str : end);
}

/// Clear comments
void stringClearComments(char* str, char ch) {
	for ( ; *str; str++)
		if (*str == ch)
			while (*str != '\0')
				*str++ = '\0';
}

/// Save the address of the character after each \n
/// Replace \n with \0, therefore this function returns array of pointers to char*
char** strArrMake(char* str, int flines) {
	
	char** arrF = (char**) malloc(sizeof(char*) * flines);
	int k = 0;
	arrF[k++] = str;
	
	//printf("arrF %d %d\n", 0, *arrF[0]);	
	while (*str) {
		if (*str == '\n') {
			*str = '\0';
			arrF[k++] = ++str;
		} else
			str++;
	}
	
	return (k == flines ? arrF : NULL);
}

/// Show string array
void strArrShow(char** arrF, int flines) {
	for (int i = 0; i < flines; i++)
		printf("%p %d |%s|\n", arrF[i], i, arrF[i]);
}

/// Array trim line
void strArrTrim(char** arrF, int flines) {
	for (int i = 0; i < flines; i++)
		if (strlen(arrF[i]) > 0)
			arrF[i] = stringTrimLine(arrF[i]);
}

/// Array clear comments
void strArrComments(char** arrF, int flines, char ch) {
	for (int i = 0; i < flines; i++)
		if (strlen(arrF[i]) > 0)
			stringClearComments(arrF[i], ch);
}

/// Find string by searching all lines, return index
int strArrIndex(char** arrF, int flines, const char* str) {
	for (int i = 0; i < flines; i++)
		if (strstr(arrF[i], str) == arrF[i])
			return i;
	
	return -1;
}

/// Count lines with specified length, from index to end
int strArrCount(char** arrF, int flines, int ind, int len) {
	int cc = 0;
	for (int i = ind; i < flines; i++)
		if ((int)strlen(arrF[i]) > len)
			cc++;
	
	return cc;
}

/// Line element
double dataElem(char* start, int ind) {
	char* end = start+strlen(start);
	char* pos = start;
	int cc = 1;
	
	for ( ; pos <= end; pos++) {
		if (*pos == ';' || *pos == '\0') {
			
			if (cc == ind) {
				int vlen = pos-start;
				if (vlen > 0 && vlen < 255) {
					for (int i = 0; i < vlen; i++)
						elembuff[i] = *start++;
					elembuff[vlen] = '\0';
					
					//printf("%d|%s|\n", vlen, elembuff);
					return atof(elembuff);
				} else
					return 0;
			}
			
			start = pos+1;
			cc++;
		}
	}
	
	return 0x32DCD5;
}

/// Open file and save contents as char*
char* openFile(const char* fname) {
	
	/// Open file
	FILE* fptr = fopen(fname, "rb");
	if (fptr == NULL)
		return NULL;
	
	/// Seek to end to find file size
	fseek(fptr, 0, SEEK_END);
	int flen = ftell(fptr);
	rewind(fptr);
	
	/// Read file in char array
	char* fbuf = (char*) malloc(sizeof(char) * (flen+1));
	int fch = fread(fbuf, sizeof(char), flen, fptr);
	if (fch != flen)
		fbuf[0] = '\0';
	
	/// Close string
	fbuf[flen] = '\0';
	
	/// Close file
	fclose(fptr);
	
	return fbuf;
}

/// Read file and return struct
struct vizread readFile(const char* fname) {
	
	/// String data
	char* fbuf = openFile(fname);
	//stringShowRaw(fbuf, fbuf+strlen(fbuf)+1);
	
	/// Replace line endings
	stringLineEnd(fbuf);
	//stringShowRaw(fbuf, fbuf+strlen(fbuf)+1);
	
	/// Count new line characters
	int flines = stringCountChar(fbuf, fbuf+strlen(fbuf)+1, '\n')+1;
	//printf("lines %d\n", flines);
	
	/// Make string array
	char** arrF = strArrMake(fbuf, flines);
	//strArrShow(arrF, flines);
	
	/// Trim each line
	strArrTrim(arrF, flines);
	
	/// Parsing of # directives here
	
	/// Clear # comments
	strArrComments(arrF, flines, '#');
	
	printf("\narrF\n");
	strArrShow(arrF, flines);
	
	/// Result
	struct vizread res;
	
	return res;
}

