/// String functions header

struct vizdata readFile(const char* fname);

