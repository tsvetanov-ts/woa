/// ICrA header

struct vizres makeICrA(double** matW, int rows, int cols, int icavar, int icamth, int matcnt);
void freevres(struct vizres vres);
void freevdata(struct vizdata vdata);

