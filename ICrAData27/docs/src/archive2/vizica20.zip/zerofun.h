/// Zero/show functions of array/matrix header

void zeroIntArray(int* arrA, int size);
void showIntArray(int* arrA, int size);
void zeroIntMatrix(int** matA, int rows, int cols);
void showIntMatrix(int** matA, int rows, int cols);

void zeroDoubleArray(double* arrA, int size);
void showDoubleArray(double* arrA, int size);
void zeroDoubleMatrix(double** matA, int rows, int cols);
void showDoubleMatrix(double** matA, int rows, int cols);

