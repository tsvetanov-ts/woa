/**
 * 
 * VizicA
 * 
 * Author: Nikolay Ikonomov
 * Version: alpha20
 * Date: December 29, 2019
 * Compiled by: GCC 7.3.0 (Linux), TDM-GCC 5.1.0 (Win32/Win64)
 * 
 */

/// FLTK uses WIN32 flag
#if defined(_WIN32) && !defined(WIN32)
#define WIN32
#endif

#include <FL/gl.h>
#include <FL/glu.h>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Gl_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Text_Buffer.H>
#include <FL/Fl_Text_Display.H>

#include <FL/Fl_Tile.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Menu_Item.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Spinner.H>

#include <FL/Fl_File_Chooser.H>
#include <FL/fl_draw.H>
#include <png.h>

#include "vizica.h"
#include "strfun.h"
#include "icra.h"
#include "mytable.h"
#include "zerofun.h"

/// Global variables
Fl_Window* mainWin;
Fl_Choice* chSep;
Fl_Choice* chVar;
Fl_Choice* chMth;
Fl_Check_Button* chHdr;
Fl_Check_Button* chTr;
Fl_Spinner* chMatCnt;
Fl_Text_Buffer* buffMsg;
Fl_Choice* chTable;

/// Buffers
time_t* ttbuff = (time_t*) malloc(sizeof(time_t));
char* timebuff = (char*) malloc(sizeof(char) * 32);
char* filebuff = (char*) malloc(sizeof(char) * 256);
char* strbuff  = (char*) malloc(sizeof(char) * 256);
char* msgbuff  = (char*) malloc(sizeof(char) * 256);

struct vizfile vfile;
struct vizdata vdata;
struct vizres vres;
MyTable* vtable;

/// Free vfile
void freevfile() {
	if (vfile.fbuf != NULL && vfile.buf > 0) {
		free(vfile.fbuf);
		vfile.buf = -1;
	}
	if (vfile.arrF != NULL && vfile.flines > 0) {
		free(vfile.arrF);
		vfile.flines = -1;
	}
}

/// Free vdata
void freevdata() {
	if (vdata.matW != NULL && vdata.rW > 0) {
		for (int i = 0; i < vdata.rW; i++)
			free(vdata.matW[i]);
		free(vdata.matW);
		vdata.rW = vdata.cW = -1;
	}
	if (vdata.rhead != NULL && vdata.rsize > 0) {
		for (int i = 0; i < vdata.rsize; i++)
			free(vdata.rhead[i]);
		free(vdata.rhead);
		vdata.rsize = -1;
	}
	if (vdata.chead != NULL && vdata.csize > 0) {
		for (int i = 0; i < vdata.csize; i++)
			free(vdata.chead[i]);
		free(vdata.chead);
		vdata.csize = -1;
	}
}

/// Free vres
void freevres() {
	if (vres.matR != NULL && vres.size > 0) {
		for (int i = 0; i < vres.size; i++)
			free(vres.matR[i]);
		free(vres.matR);
		vres.size = -1;
	}
}

/// Message
void msg(const char* m) {
	time(ttbuff);
	strftime(timebuff, 32, "%H:%M:%S", localtime(ttbuff));
	sprintf(msgbuff, "%s %s\n", timebuff, m);
	buffMsg->append(msgbuff);
}

/// Listen for clean
void listenClean(Fl_Widget* wdj, void* ptr) {
	/// Clear table first
	vtable->clear();
	vtable->myCellData(NULL,-1,-1, NULL,-1, NULL,-1, 0);
	/// Clear global data
	freevfile();
	freevdata();
	freevres();
	/// Clear messages
	buffMsg->remove(0, buffMsg->length());
	msg("VizicA");
}

/// Listen for method change
void listenMethod(Fl_Widget* wdj, void* ptr) {
	int val = int( ((Fl_Choice*) wdj)->value() );
	if (val == 0) {
		chMatCnt->value(1);
		chHdr->activate();
		chTr->activate();
		chMatCnt->deactivate();
	} else {
		chHdr->value(0);
		chTr->value(0);
		chHdr->deactivate();
		chTr->deactivate();
		chMatCnt->activate();
	}
}

/// Listen for open file
void listenOpen(Fl_Widget* wdj, void* ptr) {
	
	/// --- FL/Fl_File_Chooser.H @line238
	/// --- src/fl_file_dir.cxx @line89
	const char* fn = fl_file_chooser("Open file", "*", NULL, 0);
	if (fn == NULL)
		return;
	
	/// Open file
	char* fbuf = openFile(fn);
	if (fbuf == NULL) {
		msg("Could not open file");
		return;
	} else if (strlen(fbuf) <= 0) {
		msg("File has zero length");
		free(fbuf);
		return;
	} else {
		sprintf(strbuff, "File opened (%d bytes) %s", (int)strlen(fbuf), fn);
		msg(strbuff);
	}
	
	/// Free resources
	freevfile();
	
	/// Load file
	vfile = loadFile(fbuf);
	
	if (vfile.flines == -4) {
		msg("File should have at least 4 rows");
		return;
	}
	
	if (vfile.sep == 0 || vfile.sep == 1 || vfile.sep == 2)
		chSep->value(vfile.sep);
	if (vfile.hdr == 0 || vfile.hdr == 1)
		chHdr->value(vfile.hdr);
	if (vfile.tr == 0 || vfile.tr == 1)
		chTr->value(vfile.tr);
	
	if (vfile.icavar >= 1 && vfile.icavar <= 5)
		chVar->value(vfile.icavar-1);
	if (vfile.icamth >= 1 && vfile.icamth <= 5) {
		chMth->value(vfile.icamth-1);
		listenMethod(chMth, NULL);
	}
	if (vfile.matcnt >= 1 && vfile.matcnt <= 9999)
		chMatCnt->value(vfile.matcnt);
	
	sprintf(strbuff, "File loaded (%d lines)", vfile.flines);
	msg(strbuff);
}

/// Listen for save file
void listenSave(Fl_Widget* wdj, void* ptr) {
	
	if (vfile.flines == -1) {
		msg("Nothing to save");
		return;
	}
	
	/// --- FL/Fl_File_Chooser.H @line238
	/// --- src/fl_file_dir.cxx @line89
	const char* fn = fl_file_chooser("Save file", "*", NULL, 0);
	if (fn == NULL)
		return;
	
	int s = saveFile(fn, vfile, chSep->value(), chHdr->value(), chTr->value(),
		chVar->value()+1, chMth->value()+1, chMatCnt->value());
	
	if (s == -2) {
		msg("Could not save file");
		return;
	}
	
	if (s == 0 || s == 1 || s == 2)
		vfile.sep = s;
	
	sprintf(strbuff, "File saved (%d lines) %s", vfile.flines, fn);
	msg(strbuff);
}

/// Listen for calculations
void listenCalc(Fl_Widget* wdj, void* ptr) {
	
	if (vfile.flines == -1) {
		msg("No data to calculate");
		return;
	}
	
	/// Clear result
	vtable->clear();
	vtable->myCellData(NULL,-1,-1, NULL,-1, NULL,-1, 0);
	
	/// Free resources
	freevdata();
	
	/// Read file
	vdata = readFile(vfile, chSep->value(), chHdr->value(), chTr->value());
	
	//printf("\nmatW\n");
	//showDoubleMatrix(vdata.matW, vdata.rW, vdata.cW);
	
	if (vdata.rW == -5) {
		msg("All column sizes per row must match (including the header)");
		return;
	}
	
	if (vdata.rW == -3) {
		msg("Minimum matrix size is 3x3");
		return;
	}
	
	if (chMth->value() > 0) {
		if (chMatCnt->value() < 3) {
			msg("Non-standard methods require at least 3 matrices");
			return;
		}
		
		if ((double)vdata.rW/(int)chMatCnt->value() < 3.0) {
			sprintf(strbuff, "Each matrix must have at least 3 rows: %d/%d=%.6f",
				vdata.rW, (int)chMatCnt->value(), (double)vdata.rW/chMatCnt->value());
			msg(strbuff);
			return;
		}
		
		if (vdata.rW % (int)chMatCnt->value() != 0) {
			sprintf(strbuff, "Matrix rows must be fully divisible by matrix count: %d/%d=%.6f",
				vdata.rW, (int)chMatCnt->value(), (double)vdata.rW/chMatCnt->value());
			msg(strbuff);
			return;
		}
		
		sprintf(strbuff, "Matrix rows: %d/%d=%.6f",
			vdata.rW, (int)chMatCnt->value(), (double)vdata.rW/chMatCnt->value());
		msg(strbuff);
	}
	
	/// Free resources
	freevres();
	
	/// Make ICrA
	vres = makeICrA(vdata.matW, vdata.rW, vdata.cW, chVar->value()+1, chMth->value()+1, chMatCnt->value());
	
	printf("\nmatR\n");
	showDoubleMatrix(vres.matR, vres.size, vres.size);
	
	/// View result
	vtable->clear();
	vtable->rows(vres.size);
	vtable->cols(vres.size);
	chTable->value(1);
	if (chTr->value()) /// transpose
		vtable->myCellData(vres.matR,vres.size,vres.size, vdata.chead,vdata.csize, vdata.rhead,vdata.rsize, 1);
	else /// normal
		vtable->myCellData(vres.matR,vres.size,vres.size, vdata.rhead,vdata.rsize, vdata.chead,vdata.csize, 1);
	
	msg("Success");
}

/// Listen for check alpha
void listenChAlpha(Fl_Widget* wdj, void* ptr) {
	if (vdata.rW == -1 || vres.size == -1) return;
	double val = double( ((Fl_Spinner*)wdj)->value() );
	vtable->myLimitA(val);
	vtable->redraw();
}

/// Listen for check beta
void listenChBeta(Fl_Widget* wdj, void* ptr) {
	if (vdata.rW == -1 || vres.size == -1) return;
	double val = double( ((Fl_Spinner*)wdj)->value() );
	vtable->myLimitB(val);
	vtable->redraw();
}

/// Listen for digits
void listenChDigits(Fl_Widget* wdj, void* ptr) {
	if (vdata.rW == -1 || vres.size == -1) return;
	int val = int( ((Fl_Spinner*) wdj)->value() );
	vtable->myDigits(val);
	vtable->redraw();
}

/// Listen for column width
void listenChWidth(Fl_Widget* wdj, void* ptr) {
	if (vdata.rW == -1 || vres.size == -1) return;
	int val = int( ((Fl_Spinner*) wdj)->value() );
	vtable->row_header_width(val);
	vtable->col_width_all(val);
	vtable->redraw();
}

/// Listen for table display
void listenChTable(Fl_Widget* wdj, void* ptr) {
	if (vdata.rW == -1 || vres.size == -1) return;
	int val = int( ((Fl_Choice*) wdj)->value() );
	
	if (val) { /// result
		vtable->clear();
		vtable->rows(vres.size);
		vtable->cols(vres.size);
		if (chTr->value()) /// transpose
			vtable->myCellData(vres.matR,vres.size,vres.size, vdata.chead,vdata.csize, vdata.rhead,vdata.rsize, val);
		else /// normal
			vtable->myCellData(vres.matR,vres.size,vres.size, vdata.rhead,vdata.rsize, vdata.chead,vdata.csize, val);
		
	} else { /// input
		vtable->clear();
		vtable->rows(vdata.rW);
		vtable->cols(vdata.cW);
		if (chTr->value()) /// transpose
			vtable->myCellData(vdata.matW,vdata.rW,vdata.cW, vdata.chead,vdata.csize, vdata.rhead,vdata.rsize, val);
		else /// normal
			vtable->myCellData(vdata.matW,vdata.rW,vdata.cW, vdata.rhead,vdata.rsize, vdata.chead,vdata.csize, val);
	}
	
	vtable->redraw();
}

/// Close window
void listenClose(Fl_Widget* wdj, void* ptr) {
	((Fl_Window*)ptr)->hide();
}

/// Export window
void listenExpWin(Fl_Widget* wdj, void* ptr) {
	
	Fl_Window* expWin = new Fl_Window(
		mainWin->x()+mainWin->w()/2-350, mainWin->y()+mainWin->h()/2-250,
		700, 500, "Export");
	expWin->color(FL_WHITE);
	
	Fl_Text_Buffer* buffExp = new Fl_Text_Buffer();
	buffExp->text(
		"Export\n\n"
		);
	
	Fl_Text_Display* textExp = new Fl_Text_Display(5, 5, 690, 460, NULL);
	textExp->textsize(14);
	textExp->wrap_mode(Fl_Text_Display::WRAP_AT_BOUNDS, 0);
	textExp->buffer(buffExp);
	
	Fl_Button* btnClose = new Fl_Button(300, 470, 100, 25, "Close");
	btnClose->color(FL_WHITE);
	btnClose->callback(listenClose, expWin);
	
	expWin->resizable(textExp);
	expWin->set_modal();
	expWin->end();
	expWin->show();
}

/// Information window
void listenInfoWin(Fl_Widget* wdj, void* ptr) {
	
	Fl_Window* infoWin = new Fl_Window(
		mainWin->x()+mainWin->w()/2-350, mainWin->y()+mainWin->h()/2-250,
		700, 500, "Information");
	infoWin->color(FL_WHITE);
	
	Fl_Text_Buffer* buffInfo = new Fl_Text_Buffer();
	buffInfo->text(
		"This application operates entirely with keyboard shortcuts.\n\n"
		"Ctrl-R: Reset camera\n"
		"Ctrl-F: Full screen\n"
		"Ctrl-G: Wireframe\n"
		"Ctrl-H: Crosshair\n"
		"Ctrl-B: Background\n\n"
		"F2: Screen information\n"
		"F5/F6: Camera speed\n"
		"F7/F8: Rotation angle in degrees\n\n"
		">>> Keyboard\n"
		"Switch between movement and marker with C key.\n"
		"Movement: move the camera with WASD, change elevation with QE, rotate with Shift-WASDQE.\n"
		"Marker: move the cell marker with AD on X axis, WS on Y axis, QE on Z axis.\n"
		"Alternatively, use the arrows and PgUp/PgDn.\n\n"
		">>> Mouse\n"
		"Zoom with Z/X, Home/End, or the mouse wheel. Mouse drag moves the camera diagonally.\n\n"
		">>> Parameters\n"
		"Switch parameters with Tab/Shift-Tab, modify parameters with Space/Shift-Space.\n\n"
		">>> Cell modification\n"
		"Navigate to Block and Start, use Space to select the desired values. "
		"Press Space on the result selector below them to copy the values to the matrix. "
		"Press Shift-Space to clear the matrix cell to Air.\n\n"
		">>> Model\n"
		"Navigate to the algorithm selector. Create model with M, change time steps with J/K.\n\n"
		">>> Files\n"
		"Ctrl-O: Load matrix\n"
		"Ctrl-L: Save matrix\n"
		"Ctrl-P: Screenshot\n\n"
		">>> Misc\n"
		"F1: This information\n"
		"F9/F10/F11: Rotation arcs\n"
		"F12: About the application\n"
		"Escape or Alt-F4: Exit\n\n"
		);
	
	Fl_Text_Display* textInfo = new Fl_Text_Display(5, 5, 690, 460, NULL);
	textInfo->textsize(14);
	textInfo->wrap_mode(Fl_Text_Display::WRAP_AT_BOUNDS, 0);
	textInfo->buffer(buffInfo);
	
	Fl_Button* btnClose = new Fl_Button(300, 470, 100, 25, "Close");
	btnClose->color(FL_WHITE);
	btnClose->callback(listenClose, infoWin);
	
	infoWin->resizable(textInfo);
	infoWin->set_modal();
	infoWin->end();
	infoWin->show();
}

/// About window
void listenAboutWin(Fl_Widget* wdj, void* ptr) {
	
	Fl_Window* aboutWin = new Fl_Window(
		mainWin->x()+mainWin->w()/2-350, mainWin->y()+mainWin->h()/2-250,
		700, 500, "About");
	aboutWin->color(FL_WHITE);
	
	Fl_Text_Buffer* buffAbout = new Fl_Text_Buffer();
	buffAbout->text(
		"VizicA\n\n"
		"Visualize InterCriteria Analysis\n\n"
		"Author: Nikolay Ikonomov\n"
		"Version: alpha20\n"
		"Date: December 29, 2019\n"
		"Compiled by: GCC 7.3.0 (Linux), TDM-GCC 5.1.0 (Win32/Win64)\n\n"
		"VizicA is based in part on the work of the FLTK project (http://www.fltk.org).\n\n"
		);
	
	Fl_Text_Display* textAbout = new Fl_Text_Display(5, 5, 690, 460, NULL);
	textAbout->textsize(14);
	textAbout->wrap_mode(Fl_Text_Display::WRAP_AT_BOUNDS, 0);
	textAbout->buffer(buffAbout);
	
	Fl_Button* btnClose = new Fl_Button(300, 470, 100, 25, "Close");
	btnClose->color(FL_WHITE);
	btnClose->callback(listenClose, aboutWin);
	
	aboutWin->resizable(textAbout);
	aboutWin->set_modal();
	aboutWin->end();
	aboutWin->show();
}

/// Exit application
void listenExit(Fl_Widget* wdj, void* ptr) {
	exit(0);
}

/// Exit window
void listenExitWin() {
	
	Fl_Window* exitWin = new Fl_Window(
		mainWin->x()+mainWin->w()/2-125, mainWin->y()+mainWin->h()/2-45,
		250, 90, "Exit");
	exitWin->color(FL_WHITE);
	
	Fl_Box* msgText = new Fl_Box(10, 20, 10, 10, "Exit the application?");
	msgText->align(FL_ALIGN_RIGHT);
	msgText->box(FL_NO_BOX);
	
	Fl_Button* btnExit = new Fl_Button(20, 50, 100, 25, "Exit");
	btnExit->color(FL_WHITE);
	btnExit->callback(listenExit, exitWin);
	
	Fl_Button* btnClose = new Fl_Button(130, 50, 100, 25, "Cancel");
	btnClose->color(FL_WHITE);
	btnClose->callback(listenClose, exitWin);
	
	exitWin->set_modal();
	exitWin->end();
	exitWin->show();
}

/// Listen for exit
void listenExit_(Fl_Widget* wdj, void* ptr) {
	listenExitWin();
}

/// Constructor
int main(int argc, char* argv[]) {
	
	/// Window
	mainWin = new Fl_Window(1200, 600, "VizicA");
	
	/// Tiles
	Fl_Tile* tile = new Fl_Tile(0, 0, 1200, 600, NULL);
	
	Fl_Group* panel1 = new Fl_Group(0, 0, 400, 190, NULL);
	panel1->box(FL_DOWN_BOX);
	panel1->color(FL_WHITE);
	
	Fl_Button* btnOpen = new Fl_Button(10, 10, 120, 25, "Open");
	btnOpen->tooltip("Open file. Parameters will be loaded if #vizica line is present in the file.");
	btnOpen->color(FL_WHITE);
	btnOpen->callback(listenOpen, btnOpen);
	
	Fl_Button* btnSave = new Fl_Button(10+120+10, 10, 120, 25, "Save");
	btnSave->tooltip("Save file. The selected parameters will be saved in #vizica line in the file.");
	btnSave->color(FL_WHITE);
	btnSave->callback(listenSave, btnSave);
	
	Fl_Button* btnClean = new Fl_Button((10+120)*2+10, 10, 120, 25, "Clean");
	btnClean->tooltip("Release all working memory used by the application.");
	btnClean->color(FL_WHITE);
	btnClean->callback(listenClean, btnClean);
	
	Fl_Menu_Item listSep[] = {
		{"Tab \\t"},
		{"Semicolon ;"},
		{"Comma ,"},
		{0}
	};
	
	Fl_Menu_Item listVar[] = {
		{"\xce\xbc-biased"},
		{"Unbiased"},
		{"\xce\xbd-biased"},
		{"Balanced"},
		{"Weighted"},
		{0}
	};
	
	Fl_Menu_Item listMth[] = {
		{"Standard"},
		{"Aggr Average"},
		{"Aggr MaxMin"},
		{"Aggr MinMax"},
		{"Criteria Pair"},
		{0}
	};
	
	chSep = new Fl_Choice(10+120+10, 10+25+10, 120, 25, "Separator");
	chSep->tooltip("Column separator in the file.");
	chSep->menu(listSep);
	
	chVar = new Fl_Choice(10+120+10, (10+25)*2+10, 120, 25, "ICrA Variant");
	chVar->tooltip("Variant for InterCriteria Analysis. This is the base algorithm.");
	chVar->menu(listVar);
	
	chMth = new Fl_Choice(10+120+10, (10+25)*3+10, 120, 25, "ICrA Method");
	chMth->tooltip("Method for InterCriteria Analysis. Standard directly applies the base algorithm. "
		"The others require at least three input matrices.");
	chMth->menu(listMth);
	chMth->callback(listenMethod, chMth);
	
	chHdr = new Fl_Check_Button((10+120)*2+10, 10+25+10, 120, 25, "Headers");
	chHdr->tooltip("Row and column headers in the file. Applies only to Standard.");
	chHdr->value(0);
	
	chTr = new Fl_Check_Button((10+120)*2+10, (10+25)*2+10, 120, 25, "Transpose");
	chTr->tooltip("Transpose the matrix. Applies only to Standard.");
	chTr->value(0);
	
	chMatCnt = new Fl_Spinner((10+120)*2+10+60, (10+25)*3+10, 60, 25, "MatCnt");
	chMatCnt->tooltip("Matrix count is applied to Aggregated and Criteria Pair.");
	chMatCnt->minimum(1);
	chMatCnt->maximum(9999);
	chMatCnt->step(1);
	chMatCnt->value(1);
	chMatCnt->deactivate();
	
	Fl_Button* btnCalc = new Fl_Button(10, (10+25)*4+10, 400-10-10, 25, "Make Calculations");
	btnCalc->tooltip("Make the calculations and display them.");
	btnCalc->color(FL_WHITE);
	btnCalc->callback(listenCalc, btnCalc);
	
	panel1->resizable(0);
	panel1->end();
	
	Fl_Group* panel2 = new Fl_Group(0, 190, 400, 410, NULL);
	panel2->box(FL_DOWN_BOX);
	panel2->color(FL_WHITE);
	
	buffMsg = new Fl_Text_Buffer();
	buffMsg->text("");
	
	Fl_Text_Display* textMsg = new Fl_Text_Display(0, 190, 400, 410, NULL);
	textMsg->textsize(14);
	textMsg->wrap_mode(Fl_Text_Display::WRAP_AT_BOUNDS, 0);
	textMsg->buffer(buffMsg);
	
	panel2->end();
	
	Fl_Group* panel3 = new Fl_Group(400, 0, 480, 120, NULL);
	panel3->box(FL_DOWN_BOX);
	panel3->color(FL_WHITE);
	
	Fl_Spinner* chAlpha = new Fl_Spinner(400+10+60, 10, 60, 25, "Alpha");
	chAlpha->tooltip("Table colors: \xce\xbc > \xce\xb1 and \xce\xbd < \xce\xb2 - positive consonance (green), "
		"\xce\xbc < \xce\xb1 and \xce\xbd > \xce\xb2 - negative consonance (red), "
		"all other cases - dissonance (magenta).");
	chAlpha->minimum(0.5);
	chAlpha->maximum(1.0);
	chAlpha->step(0.01);
	chAlpha->value(0.75);
	chAlpha->callback(listenChAlpha, chAlpha);
	
	Fl_Spinner* chBeta = new Fl_Spinner(400+10+60, 10+25+10, 60, 25, "Beta");
	chBeta->tooltip("Table colors: \xce\xbc > \xce\xb1 and \xce\xbd < \xce\xb2 - positive consonance (green), "
		"\xce\xbc < \xce\xb1 and \xce\xbd > \xce\xb2 - negative consonance (red), "
		"all other cases - dissonance (magenta).");
	chBeta->minimum(0.0);
	chBeta->maximum(0.5);
	chBeta->step(0.01);
	chBeta->value(0.25);
	chBeta->callback(listenChBeta, chBeta);
	
	Fl_Spinner* chDigits = new Fl_Spinner(400+(10+60)*2+60, 10, 60, 25, "Digits");
	chDigits->tooltip("Digits after the decimal separator.");
	chDigits->minimum(0);
	chDigits->maximum(16);
	chDigits->step(1);
	chDigits->value(4);
	chDigits->callback(listenChDigits, chDigits);
	
	Fl_Spinner* chCW = new Fl_Spinner(400+(10+60)*2+60, 10+25+10, 60, 25, "Width");
	chCW->tooltip("Table column width in pixels.");
	chCW->minimum(10);
	chCW->maximum(500);
	chCW->step(10);
	chCW->value(80);
	chCW->callback(listenChWidth, chCW);
	
	Fl_Menu_Item listTable[] = {
		{"Input"},
		{"Result"},
		{"\xce\xbc only"},
		{"\xce\xbd only"},
		{"(\xce\xbc;\xce\xbd) table"},
		{0}
	};
	
	chTable = new Fl_Choice(400+10+120+10+60, (10+25)*2+10, 120, 25, "Table");
	chTable->tooltip("Display the tables.");
	chTable->menu(listTable);
	chTable->callback(listenChTable, chTable);
	
	Fl_Button* btnExport = new Fl_Button(400+(10+120)*2+10+60, 10, 120, 25, "Export");
	btnExport->tooltip("Export the tables.");
	btnExport->color(FL_WHITE);
	btnExport->callback(listenExpWin, btnExport);
	
	Fl_Button* btnInfo = new Fl_Button(400+(10+120)*2+10+60, 10+25+10, 120, 25, "Information");
	btnInfo->tooltip("Information for the application.");
	btnInfo->color(FL_WHITE);
	btnInfo->callback(listenInfoWin, btnInfo);
	
	Fl_Button* btnAbout = new Fl_Button(400+(10+120)*2+10+60, (10+25)*2+10, 120, 25, "About");
	btnAbout->tooltip("About the application.");
	btnAbout->color(FL_WHITE);
	btnAbout->callback(listenAboutWin, btnAbout);
	
	panel3->resizable(0);
	panel3->end();
	
	Fl_Group* panel4 = new Fl_Group(400, 120, 480, 480, NULL);
	panel4->box(FL_DOWN_BOX);
	panel4->color(FL_WHITE);
	
	vtable = new MyTable(400, 120, 480, 480, NULL);
	
	panel4->end();
	
	Fl_Group* panel5 = new Fl_Group(880, 0, 320, 600, NULL);
	panel5->box(FL_DOWN_BOX);
	panel5->color(FL_WHITE);
	
	Fl_Button* btnScr = new Fl_Button(880+10, 10, 60, 25, "Scr");
	btnScr->tooltip("Screenshot of the application.");
	btnScr->color(FL_WHITE);
	
	Fl_Button* btnPng = new Fl_Button(880+10+60+10, 10, 60, 25, "PNG");
	btnPng->tooltip("Save the graphic as PNG.");
	btnPng->color(FL_WHITE);
	
	Fl_Button* btnTex = new Fl_Button(880+(10+60)*2+10, 10, 60, 25, "TeX");
	btnTex->tooltip("Save the graphic as TeX.");
	btnTex->color(FL_WHITE);
	
	Fl_Spinner* chPoints = new Fl_Spinner(880+(10+60)*3+10+30, 10, 50, 25, "Size");
	chPoints->tooltip("Size of the plot points.");
	chPoints->minimum(1);
	chPoints->maximum(20);
	chPoints->step(1);
	chPoints->value(5);
	
	panel5->end();
	
	tile->end();
	
	/// Initialize variables
	vfile.buf = vfile.flines = -1;
	vdata.rW = vdata.cW = vdata.rsize = vdata.csize = -1;
	vres.size = -1;
	msg("VizicA");
	
	mainWin->end();
	mainWin->resizable(mainWin);
	mainWin->callback(listenExit_, mainWin);
	
	mainWin->show(argc, argv);
	return Fl::run();
}

