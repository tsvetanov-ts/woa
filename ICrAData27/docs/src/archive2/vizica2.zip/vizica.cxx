/**
 * 
 * VizicA
 * 
 * Author: Nikolay Ikonomov
 * Version: alpha2
 * Date: December 13, 2019
 * Compiled by: GCC 7.3.0 (Linux), TDM-GCC 5.1.0 (Win32/Win64)
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "zerofun.h"

/// Make criteria matrix
double** makeCrit(double** matA, int rows, int cols) {
	
	double** matC = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matC[i] = (double*) malloc(sizeof(double) * ((cols*(cols-1))/2));
	zeroDoubleMatrix(matC, rows, (cols*(cols-1))/2);
	
	int cc = 0;
	for (int i = 0; i < rows; i++) {
		for (int k = 0; k < cols-1; k++) {
			for (int j = k; j < cols-1; j++) {
				matC[i][cc] = (matA[i][k]-matA[i][j+1] > 0 ? 1 : (matA[i][k]-matA[i][j+1] < 0 ? -1 : 0));
				cc++;
			}
		}
		cc = 0;
	}
	
	return matC;
}

/// Counter A - equal elements:  0==0  -1==-1  1==1  (flag==1)   0=/=0  -1==-1  1==1  (flag==0)
double counterA(double* arrA, double* arrB, int size, int flag) {
	
	int cc = 0;
	for (int i = 0; i < size; i++) {
		if (((arrA[i] ==  1) && (arrB[i] ==  1)) ||
			((arrA[i] == -1) && (arrB[i] == -1)) ||
			((arrA[i] ==  0) && (arrB[i] ==  0) && flag))
			cc++;
	}
	
	return (double)cc/size;
}

/// Counter B - different elements:  0==0  -1=/=1  1=/=-1  (flag==0)   0=/=0  -1=/=1  1=/=-1  (flag==1)
double counterB(double* arrA, double* arrB, int size, int flag) {
	
	int cc = 0;
	for (int i = 0; i < size; i++) {
		if (((arrA[i] == -1) && (arrB[i] ==  1)) ||
			((arrA[i] ==  1) && (arrB[i] == -1)) ||
			((arrA[i] ==  0) && (arrB[i] ==  0) && flag))
			cc++;
	}
	
	return (double)cc/size;
}

/// Make result - mubiased1 flags 1 0, unbiased2 flags 0 0, nubiased3 flags 0 1
double** makeResult(double** matC, int rows, int cols, int method) {
	
	double** matR = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matR[i] = (double*) malloc(sizeof(double) * rows);
	zeroDoubleMatrix(matR, rows, rows);
	
	for (int i = 0; i < rows; i++) {
		/// upper triangular - matrix MU-A
		for (int j = i+1; j < rows; j++)
			matR[i][j] = counterA(matC[i], matC[j], cols, (method==1 ? 1 : 0));
		/// lower triangular - matrix NU-B
		for (int j = 0; j < i; j++)
			matR[i][j] = counterB(matC[i], matC[j], cols, (method==3 ? 1 : 0));
		/// ignore diagonal elements
	}
	
	return matR;
}


int main() {
	
	printf("VizicA\n");
	
	int rows = 4;
	int cols = 5;
	
	double** matW = (double**) malloc(sizeof(double) * rows);
	for (int i = 0; i < rows; i++)
		matW[i] = (double*) malloc(sizeof(double) * cols);
	zeroDoubleMatrix(matW, rows, cols);
	
	matW[0][0] = 6; matW[0][1] = 5; matW[0][2] = 3; matW[0][3] = 7; matW[0][4] = 6;
	matW[1][0] = 7; matW[1][1] = 7; matW[1][2] = 8; matW[1][3] = 1; matW[1][4] = 3;
	matW[2][0] = 4; matW[2][1] = 3; matW[2][2] = 5; matW[2][3] = 9; matW[2][4] = 1;
	matW[3][0] = 4; matW[3][1] = 5; matW[3][2] = 6; matW[3][3] = 7; matW[3][4] = 8;
	
	printf("\nmatW\n");
	showDoubleMatrix(matW, rows, cols);
	
	double** matC = makeCrit(matW, rows, cols);
	
	printf("\nmatC\n");
	showDoubleMatrix(matC, rows, (cols*(cols-1))/2);
	
	double** matR = makeResult(matC, rows, (cols*(cols-1))/2, 1);
	
	printf("\nmatR\n");
	showDoubleMatrix(matR, rows, rows);
	
	
	return 0;
}

