/// MyTable header

/// FLTK uses WIN32 flag
#if defined(_WIN32) && !defined(WIN32)
#define WIN32
#endif

#include <FL/Fl.H>
#include <FL/Fl_Table_Row.H>
#include <FL/fl_draw.H>

/// MyTable
class MyTable : public Fl_Table_Row {
	private:
		double** wdata;
		int      wsize;
		char**   rhead;
		int      rsize;
		char**   chead;
		int      csize;
		double    lima;
		double    limb;
	protected:
		void draw_cell(TableContext context, int r=0, int c=0, int x=0, int y=0, int w=0, int h=0);
	public:
		MyTable(int x, int y, int w, int h, const char* lbl);
		void myCellData(double** wd, int ws, char** wrh, int wrs, char** wch, int wcs);
		void myLimitA(double a);
		void myLimitB(double b);
		Fl_Color myColor(int r, int c);
};

