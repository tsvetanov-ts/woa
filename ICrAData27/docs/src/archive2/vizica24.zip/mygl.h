/// MyGL header

#include <FL/Fl_Gl_Window.H>

class MyWindow : public Fl_Gl_Window {
	private:
		void draw();
	public:
		MyWindow(int x, int y, int w, int h, const char* lbl);
		int handle(int event);
		
		int mX   = 0;        /// mouse position X
		int mY   = 0;        /// mouse position Y
		int mDX  = 0;        /// mouse delta X
		int mDY  = 0;        /// mouse delta Y
		int mpix = 1;        /// mouse pixels
		
		int crosshair = 1;   /// crosshair
		int wireframe = 0;   /// wireframe
		int backclr   = 1;   /// background
		int circle1   = 0;   /// circle Oxy
		int circle2   = 0;   /// circle Oxz
		int circle3   = 0;   /// circle Oyz
		
		int kbdstate  = 1;   /// keyboard
		
		double acc  =  0.5;  /// movement accuracy
		double eyeX = -4.0;  /// camera eye X
		double eyeY = -4.0;  /// camera eye Y
		double eyeZ =  8.0;  /// camera eye Z
		double locX =  0.0;  /// look at origin X
		double locY =  0.0;  /// look at origin Y
		double locZ =  5.0;  /// look at origin Z
		
		int kbd = 0;         /// keyboard flag
		int msb = 0;         /// mouse button flag
		int msw = 0;         /// mouse wheel flag
		double theta = 15.0; /// rotation angle
		
		int xel   = 10;      /// elements on X axis
		int yel   = 10;      /// elements on Y axis
		int zel   = 1;      /// elements on Z axis
		int xmark = 0;       /// X marker
		int ymark = 0;       /// Y marker
		int zmark = 0;       /// Z marker
		
		int vcell = 4;       /// cell 4square 6hexagon
};

