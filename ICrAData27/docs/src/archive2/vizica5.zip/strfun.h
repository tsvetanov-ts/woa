/// String functions header

struct vizread readFile(const char* fname);

