/**
 * 
 * VizicA
 * 
 * Author: Nikolay Ikonomov
 * Version: alpha7
 * Date: December 16, 2019
 * Compiled by: GCC 7.3.0 (Linux), TDM-GCC 5.1.0 (Win32/Win64)
 * 
 */

#include "vizica.h"
#include "icra.h"
#include "strfun.h"
#include "zerofun.h"

int main() {
	
	printf("VizicA\n");
	
	/// filename, separator, headers, transpose
	struct vizread vread = readFile("ex1.csv", ';', 0, 1);
	
	printf("\nmatW\n");
	showDoubleMatrix(vread.matW, vread.rW, vread.cW);
	
	/// matrix1, matrix2, rows, cols, method, pair
	struct vizres vres = makeCalc(vread.matW, NULL, vread.rW, vread.cW, 1, 0);
	
	printf("\nmatR\n");
	showDoubleMatrix(vres.matR, vres.size, vres.size);
	
	return 0;
}

