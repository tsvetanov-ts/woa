/// String functions header

int strArrPar(char** arrF, int flines);
char* openFile(const char* fname);
struct vizfile loadFile(char* fbuf);
struct vizdata readFile(struct vizfile vfile, int vsep, int hdr, int tr);

