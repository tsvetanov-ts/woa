/// MyTable header

#include <FL/Fl_Table.H>

class MyTable : public Fl_Table {
	private:
		double** wdata;
		int      rdata;
		int      cdata;
		char**   rhead;
		int      rsize;
		char**   chead;
		int      csize;
		int       disp;
		double    lima;
		double    limb;
	protected:
		void draw_cell(TableContext context, int r=0, int c=0, int x=0, int y=0, int w=0, int h=0);
	public:
		MyTable(int x, int y, int w, int h, const char* lbl);
		void myCellData(double** wd, int rd, int cd, char** rh, int rs, char** ch, int cs, int ds);
		void myLimitA(double a);
		void myLimitB(double b);
		Fl_Color myColor(int r, int c);
};

