/// Zero/show functions of array/matrix

#include <stdio.h>
#include <stdlib.h>

/// Integer array
void zeroIntArray(int* arrA, int size) {
	for (int i = 0; i < size; i++)
		arrA[i] = (int)0;
}

void showIntArray(int* arrA, int size) {
	for (int i = 0; i < size; i++)
		printf("%d ", arrA[i]);
}

/// Integer matrix
void zeroIntMatrix(int** matA, int rows, int cols) {
	for (int i = 0; i < rows; i++)
		for (int j = 0; j < cols; j++)
			matA[i][j] = (int)0;
}

void showIntMatrix(int** matA, int rows, int cols) {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++)
			printf("%d ", matA[i][j]);
		printf("\n");
	}
}

/// Double array
void zeroDoubleArray(double* arrA, int size) {
	for (int i = 0; i < size; i++)
		arrA[i] = (double)0;
}

void showDoubleArray(double* arrA, int size) {
	for (int i = 0; i < size; i++)
		printf("%.2f ", arrA[i]);
}

/// Double matrix
void zeroDoubleMatrix(double** matA, int rows, int cols) {
	for (int i = 0; i < rows; i++)
		for (int j = 0; j < cols; j++)
			matA[i][j] = (double)0;
}

void showDoubleMatrix(double** matA, int rows, int cols) {
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++)
			printf("%.2f ", matA[i][j]);
		printf("\n");
	}
}

