/**
 * 
 * VizicA
 * 
 * Author: Nikolay Ikonomov
 * Version: alpha10
 * Date: December 18, 2019
 * Compiled by: GCC 7.3.0 (Linux), TDM-GCC 5.1.0 (Win32/Win64)
 * 
 */

#include "vizica.h"
#include "icra.h"
#include "strfun.h"
#include "zerofun.h"

int main() {
	
	printf("VizicA\n");
	
	/// filename, separator, headers, transpose
	struct vizdata vdata = readFile("ex1.csv");
	
	//printf("\nmatW\n");
	//showDoubleMatrix(vdata.matW, vdata.rW, vdata.cW);
	
	/// matrix, rows, cols, variant, method, matrix count
	struct vizres vres = makeICrA(vdata.matW, vdata.rW, vdata.cW, vdata.icavar, vdata.icamth, vdata.matcnt);
	
	printf("\nmatR\n");
	showDoubleMatrix(vres.matR, vres.size, vres.size);
	
	freevres(vres);
	freevdata(vdata);
	
	return 0;
}

