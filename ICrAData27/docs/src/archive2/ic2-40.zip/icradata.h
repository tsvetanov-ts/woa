/// ICrAData header

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>

#ifndef min
#define min(a,b) ((a) < (b) ? (a) : (b))
#endif
#ifndef max
#define max(a,b) ((a) > (b) ? (a) : (b))
#endif

/// Structs
struct vizfile {
	char*  fbuf;
	int     buf;
	char** arrF;
	int  flines;
	int     sep;
	int     hdr;
	int      tr;
	int  icavar;
	int  icamth;
	int  matcnt;
};

struct vizdata {
	double** matW;
	int        rW;
	int        cW;
	char**  rhead;
	int     rsize;
	char**  chead;
	int     csize;
};

struct vizres {
	double** matR;
	int      size;
};

