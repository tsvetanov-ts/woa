/// String functions header

void stringLineEnd(char* str);
double dataElem(char* start, int ind, char sep);
char* openFile(const char* fname);
struct vizfile loadFile(char* fbuf);
struct vizdata readFile(struct vizfile vfile, int sep, int hdr, int tr);
int saveFile(const char* fn, struct vizfile vfile, int icamth, int matcnt, int icavar, int sep, int hdr, int tr);
struct vizcfg readConfig();

