/// String functions header

struct vizdata readFile(const char* fname, char sep, int hdr, int tr);

