function [X,Y]=matrix_plot(A,B)
[m,n]=size(A);
j=2;X=[];Y=[];
for i=1:n
    x=A(j:end,i);
    X=[X;x];
    y=B(j:end,i);
    Y=[Y;y];
    j=j+1;
end   
plot(X,Y, 'b*')
hold on
plot([0,1],[1,0])
end