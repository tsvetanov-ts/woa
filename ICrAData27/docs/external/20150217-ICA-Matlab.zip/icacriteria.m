function [MU NU] = icacriteria(U)
%this is for calculating the values of intercriterial estimations MU and NU
%from imported data U. 
%Please, note this is more of a dirty hack rather than an optimized program 
%MU and NU are currently returned... upper triangular matrices M and N
%maybe used instead
V=zeros(size(U,1) ,(size(U,2)*(size(U,2)-1))/2);
%initializing the matrix for all calculations 
k=1;
j=1;
s=1;
t=1;
while k<=size(V,1)
    
while t<=size(V,2)
    
if t==j*size(U,2)-sum(1:j)+1
    %check when the counter j has to go up
    j=j+1;
   %if j is up return s to 1 
    s=1;
end
%since we are currently using the relations >,< and = only what follows is sufficient; will need rethink for
%other relations 
    V(k,t)=U(k,j)-U(k,j+s);
    t=t+1;
    if s+j < size(U,2)
        %ensure out of bounds error is not encountered, then synchronize s
        %and t
       s=s+1;
       % if the final position is reached return the counter to starting
       % position. This might not be needed since j should go up at that
       % moment but just in case
    else s=1;
    end
end
t=1;
j=1;
s=1;
k=k+1;
end
clear k;
clear j;
clear s;
clear t;
%for the current relations this is enough (this transforms the matrix into
%1,0,-1 (1 and -1 will be used later for a check in the generation of the
%new matrix
S=sign(V);
%%%%%%%%%%%%%% initialize the matrix for Mu 
M=zeros(size(U,1),size(U,1));
%%%%%%%%%%%

j=1;
t=1;
while j<=size(M,1)
    %calculate the number of "same" as "1 - number of different(%)" for each
    %pair
    M(j,t)=1-pdist([S(j,:); S(t,:)],'hamming');
    if t==size(M,1)
        j=j+1;
        t=j;
    else
        t=t+1;
    end
end
%since M is an upper triangular matrix we can fill it to symmetric in this
%manner
 MU = M+triu(M,1)';
 clear j;
 clear t;
%%%%%%%%%%%%%% initialize the matrix for Nu 
N=zeros(size(U,1),size(U,1));
%%%%%%
q=1;
s=1;
while q<=size(N,1)
    %calculate the number of "different" as "those whose difference is equal to 2 by absolute value" (i.e. excluding those where "0" is encountered) for each
    %pair
     N(q,s)=(sum(abs(S(q,:)-S(s,:))==2))/(size(S,2));
    if s==size(N,1)
        q=q+1;
        s=q;
    else
        s=s+1;
    end
end
%since N is an upper triangular matrix we can fill it to symmetric in this
%manner
 NU = N+triu(N,1)';
 clear s;
 clear q;
 end













