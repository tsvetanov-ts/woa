%distancecheck.m
clear all
digits(1000);
prompt = {'Enter filename:'};
dlg_title = 'CSV NAME';
num_lines = 1;
def = {'U.csv'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
if isempty(answer)
    error('No Name Given')
elseif isempty(answer{1})
        error('EMPTY STRING')
else
    name = answer{1};    
end

U=importdata(name);
[M N]=icacriteria(U)
[Mu Nu]=matrix_plot(M,N);
Mu_Nu = [Mu Nu]

Mu_Nu_sort = SORTROWS(Mu_Nu)