% https://stackoverflow.com/questions/3013382/matlab-read-files-from-directory

myfolder = 'matlabfiles2'; %uigetdir;
dirlist = dir(myfolder);

val = 0.001;
fid = fopen('result2.txt', 'w+');
for k=1:length(dirlist)
	if ~dirlist(k).isdir
		load(strcat(myfolder, filesep, dirlist(k).name));
		mat = transpose(XXX);
		fprintf(fid, '%s%.3f\n', '#res', val);
		val = val + 0.001;
		for i=1:size(mat,1)
			for j=1:size(mat,2)
				fprintf(fid, '%.16f;', mat(i,j));
			end
			fprintf(fid, '\n');
		end
	end
end
fclose(fid);
